from django.urls import path
from . import views

app_name = 'jobs'

urlpatterns = [
    # 页面
    path('', views.index, name='index'),

    # HTMX Partial Views
    path('jobs-list/', views.job_list_partial, name='job_list_partial'),
    path('job/<int:job_id>/', views.job_detail_view, name='job_detail'),

    # API-like actions
    path('job/<int:job_id>/delete/', views.job_delete_view, name='job_delete'),
    path('parse-jobs/', views.parse_jobs_view, name='parse_jobs'),
    path('save-parsed-jobs/', views.save_parsed_jobs_view, name='save_jobs'),
]