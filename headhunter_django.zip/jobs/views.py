import json
import re
import time
import html
from django.shortcuts import render, get_object_or_404
from django.db import transaction
from django.db.models import Q
from django.contrib import messages
from django.views.decorators.http import require_http_methods, require_POST
from django.http import HttpResponse, HttpResponseBadRequest
from django.template.loader import render_to_string
from .models import Job, Company
from .forms import JobForm, JobParseForm
from . import parser


# ... index, job_list_partial, job_detail_view, job_delete_view 函数保持不变 ...
def index(request):
    context = {
        'companies': Company.objects.all(),
        'statuses': Job.JobStatus.choices,
        'parse_form': JobParseForm(),
    }
    return render(request, 'jobs/index.html', context)


def job_list_partial(request):
    search_keyword = request.GET.get('search', '')
    company_id = request.GET.get('company', '')
    status = request.GET.get('status', '')
    query = Job.objects.select_related('company').all()
    if search_keyword:
        query = query.filter(Q(title__icontains=search_keyword) | Q(company__name__icontains=search_keyword))
    if company_id:
        query = query.filter(company_id=company_id)
    if status:
        query = query.filter(status=status)
    context = {'jobs': query}
    return render(request, 'jobs/partials/job_list_table.html', context)


@require_http_methods(["GET", "POST"])
def job_detail_view(request, job_id):
    job = get_object_or_404(Job, pk=job_id)
    if request.method == 'POST':
        form = JobForm(request.POST, request.FILES, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, f"职位 '{job.title}' 更新成功！")
            response = HttpResponse(status=204)
            response['HX-Refresh'] = 'true'
            return response
    else:
        form = JobForm(instance=job)
    return render(request, 'jobs/partials/job_detail_panel.html', {'job': job, 'form': form})


@require_POST
def job_delete_view(request, job_id):
    job = get_object_or_404(Job, pk=job_id)
    job_title = job.title
    job.delete()
    messages.success(request, f"职位 '{job_title}' 已被删除。")
    response = HttpResponse(status=204)
    response['HX-Refresh'] = 'true'
    return response


@require_POST
def parse_jobs_view(request):
    form = JobParseForm(request.POST, request.FILES)
    if not form.is_valid():
        return HttpResponseBadRequest("表单无效，请上传文件或输入文本。")

    texts = []
    if form.cleaned_data['file_upload']:
        texts = parser.get_texts_from_file(form.cleaned_data['file_upload'])
    elif form.cleaned_data['text_content']:
        texts = [form.cleaned_data['text_content']]

    if not texts:
        messages.warning(request, "未从文件中提取到任何文本内容。")
        return render(request, 'jobs/partials/job_preview_results.html', {'parsed_jobs': []})

    parsed_results = []
    for text in texts:
        result = parser.call_qwen_api(text)
        if "error" not in result and result:
            parsed_results.append(result)
        # time.sleep(0.5)

    return render(request, 'jobs/partials/job_preview_results.html',
                  {'parsed_jobs': parsed_results, 'total': len(texts)})


@require_POST
def save_parsed_jobs_view(request):
    try:
        saved_count = 0
        form_indexes = sorted(list(set([key.split('-')[1] for key in request.POST if key.startswith('form-')])))
        jobs_to_save = []

        for i in form_indexes:
            job_data = {
                'title': request.POST.get(f'form-{i}-title', ''),
                'company_name': request.POST.get(f'form-{i}-company_name', '未知公司'),
                'department': request.POST.get(f'form-{i}-department', ''),
                'salary_range': request.POST.get(f'form-{i}-salary_range', ''),
                'level_set': [s.strip() for s in request.POST.get(f'form-{i}-level_set', '').split(',') if s.strip()],
                'locations': [s.strip() for s in request.POST.get(f'form-{i}-locations', '').split(',') if s.strip()],
                'skills': [s.strip() for s in request.POST.get(f'form-{i}-skills', '').split(',') if s.strip()],
                'job_description': request.POST.get(f'form-{i}-job_description', ''),
                'job_requirement': request.POST.get(f'form-{i}-job_requirement', ''),
                'notes': request.POST.get(f'form-{i}-notes', ''),
            }
            jobs_to_save.append(job_data)

        with transaction.atomic():
            for job_data in jobs_to_save:
                company_name = job_data.pop('company_name', '未知公司')
                company, _ = Company.objects.get_or_create(name=company_name)

                valid_fields = {f.name for f in Job._meta.get_fields()}
                filtered_data = {key: value for key, value in job_data.items() if key in valid_fields}

                Job.objects.create(company=company, **filtered_data)
                saved_count += 1

        messages.success(request, f"成功保存 {saved_count} 条新职位！")
        response = HttpResponse(status=204)
        response['HX-Refresh'] = 'true'
        return response

    except Exception as e:
        messages.error(request, f"保存过程中发生严重错误: {e}")
        print(f"保存职位时出错: {e}")
        return HttpResponse(status=500, content=f"保存失败，请检查服务器日志。错误: {e}")