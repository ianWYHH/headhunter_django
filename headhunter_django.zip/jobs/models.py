from django.db import models
from django.utils import timezone

class Company(models.Model):
    name = models.CharField(max_length=255, unique=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']
        verbose_name = "公司"
        verbose_name_plural = "公司"

class Job(models.Model):
    class JobStatus(models.TextChoices):
        PENDING = '待处理', '待处理'
        IN_PROGRESS = '进行中', '进行中'
        CLOSED = '已关闭', '已关闭'
        SUCCESS = '成功', '成功'

    title = models.CharField(max_length=255, db_index=True)
    company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='jobs')
    department = models.CharField(max_length=255, blank=True, null=True)
    salary_range = models.CharField(max_length=100, blank=True, null=True)
    level_set = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=50, choices=JobStatus.choices, default=JobStatus.PENDING, db_index=True)
    locations = models.JSONField(default=list, blank=True)
    skills = models.JSONField(default=list, blank=True)
    job_description = models.TextField(blank=True, null=True)
    job_requirement = models.TextField(blank=True, null=True)
    keywords = models.JSONField(default=list, blank=True)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.title} at {self.company.name}"

    class Meta:
        ordering = ['-updated_at']
        verbose_name = "职位"
        verbose_name_plural = "职位"