# 文件路径: jobs/parser.py

import logging
import json
import re
import openai
from django.conf import settings
import pandas as pd
import docx


def call_qwen_api(text: str):
    """
    调用通义千问API，将单个职位描述文本解析为结构化的JSON对象。
    """
    api_key = settings.QWEN_API_KEY
    if not api_key or not api_key.startswith("sk-"):
        return {"error": "API密钥(QWEN_API_KEY)缺失或无效。"}

    try:
        client = openai.OpenAI(
            api_key=api_key,
            base_url="https://dashscope.aliyuncs.com/compatible-mode/v1",
            timeout=30.0,
        )

        prompt = f"""
        你是一个专业的HR助手，负责将非结构化的职位描述(JD)文本精确地解析为结构化的JSON对象。
        请严格按照以下字段和类型定义来解析下面的职位描述文本。

        **JSON输出格式:**
        - "company_name": string | 公司名称。
        - "title": string | 职位名称。
        - "department": string | 所属部门。
        - "salary_range": string | 薪资范围，如 "30-50K" 或 "面议"。
        - "level_set": string[] | 职级要求，一个字符串数组。
        - "locations": string[] | 工作地点，一个字符串数组。
        - "skills": string[] | 核心技能要求，从文本中提炼出的关键技术或能力，数组形式。
        - "job_description": string | 完整的“职位描述”或“岗位职责”部分的文本。
        - "job_requirement": string | 完整的“职位要求”或“任职资格”部分的文本。
        - "notes": string | 其他补充信息，如团队规模、汇报关系、福利待遇、面试流程等。

        **约束:**
        1. 如果某个字段在文本中找不到对应信息，请使用空字符串 "" (对于string类型) 或空数组 [] (对于string[]类型)。
        2. 返回结果必须是一个能被`json.loads()`直接解析的、纯净的JSON对象。
        3. 不要在JSON对象前后包含任何解释性文字、说明或Markdown的```json标记。

        **待解析的职位描述文本:**
        ---
        {text}
        """

        completion = client.chat.completions.create(
            model="qwen-plus",
            messages=[
                {'role': 'system',
                 'content': '你是一个专门解析职位描述的助手，总是返回一个纯净的、不带任何额外解释的JSON对象。'},
                {'role': 'user', 'content': prompt}
            ],
            temperature=0.1,
        )
        content = completion.choices[0].message.content

        if content.strip().startswith("```json"):
            content = content.strip()[7:-3].strip()

        return json.loads(content)

    except openai.Timeout as e:
        logging.error(f"调用API超时: {e}")
        return {"error": "调用AI接口超时，请检查网络或稍后重试。"}
    except Exception as e:
        logging.error(f"调用API或解析JSON时发生错误: {e}")
        return {"error": f"调用API时发生未知错误: {e}"}


def get_texts_from_file(file):
    """
    从上传的文件（txt, xlsx, docx）中提取职位描述文本列表。
    """
    try:
        if file.name.endswith('.txt'):
            content = file.read().decode("utf-8")
            return [job.strip() for job in re.split(r'\n\s*\n|\n---\n', content) if job.strip()]

        elif file.name.endswith('.xlsx'):
            df = pd.read_excel(file, engine='openpyxl').fillna('')
            return [", ".join(f"{col}: {val}" for col, val in row.items() if str(val).strip()) for _, row in
                    df.iterrows()]

        elif file.name.endswith('.docx'):
            doc = docx.Document(file)
            full_text = "\n".join([para.text for para in doc.paragraphs])
            return [full_text] if full_text.strip() else []

        else:
            return []

    except Exception as e:
        logging.error(f"解析文件 {file.name} 时出错: {e}")
        return []