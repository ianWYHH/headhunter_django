# AI Adapter Architecture

This document describes the new AI adapter architecture implemented in the Django headhunter project.

## Overview

The new AI adapter architecture provides a clean, extensible way to integrate with multiple AI model providers while maintaining backward compatibility with existing code.

## Architecture Components

### 1. Base Adapter (`AIAdapter`)

The base class that defines the interface all adapters must implement:

```python
from jobs.services.ai_adapters import AIAdapter

class CustomAdapter(AIAdapter):
    def get_api_endpoint(self) -> str: ...
    def get_headers(self, api_key: str) -> Dict[str, str]: ...
    def get_context_limit(self) -> int: ...
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]: ...
    def _make_api_call(self, api_key: str, request_data: Dict[str, Any]) -> Any: ...
    def _extract_content(self, response: Any) -> str: ...
```

### 2. OpenAI Compatible Adapter (`OpenAICompatibleAdapter`)

A specialized base class for providers that support OpenAI-compatible APIs:

```python
from jobs.services.ai_adapters import OpenAICompatibleAdapter

class MyProviderAdapter(OpenAICompatibleAdapter):
    def get_context_limit(self) -> int:
        return 32768
```

### 3. Provider-Specific Adapters

Adapters for each supported AI provider:

- **QwenAdapter**: Alibaba DashScope (Qwen models)
- **KimiAdapter**: Moonshot AI (Kimi models)  
- **DoubaoAdapter**: ByteDance Volcano Engine (Doubao models)
- **HunyuanAdapter**: Tencent Cloud (Hunyuan models)
- **ChatGLMAdapter**: Zhipu AI (ChatGLM models)
- **MiniMaxAdapter**: MiniMax AI models
- **DeepSeekAdapter**: DeepSeek AI models
- **TogetherAdapter**: Together AI models

### 4. Adapter Factory (`AIAdapterFactory`)

Creates appropriate adapter instances based on provider configuration:

```python
from jobs.services.ai_adapters import AIAdapterFactory

# Create adapter for a specific model
adapter = AIAdapterFactory.create_adapter('qwen_plus')

# Get supported providers
providers = AIAdapterFactory.get_supported_providers()
```

### 5. AI Manager (`AIManager`)

Central manager that coordinates AI operations:

```python
from jobs.services.ai_manager import ai_manager

# Make an AI request
result = ai_manager.call_model(prompt, 'qwen_plus', user)

# Check user access
access = ai_manager.check_user_access(user, 'kimi_32k')

# Get user's available models
models = ai_manager.get_user_available_models(user)
```

## Supported Providers

| Provider | Models | Context Limits | Special Features |
|----------|--------|----------------|------------------|
| **Qwen** | qwen-plus, qwen-turbo, qwen-max | 8K-32K tokens | DashScope integration |
| **Kimi** | moonshot-v1-8k/32k/128k | 8K-128K tokens | Long context support |
| **Doubao** | doubao-pro-4k/32k/128k | 4K-128K tokens | ByteDance platform |
| **Hunyuan** | hunyuan-pro, hunyuan-lite | 4K-32K tokens | Tencent Cloud |
| **ChatGLM** | glm-4, glm-3-turbo | 128K tokens | Zhipu AI |
| **MiniMax** | abab6.5-chat | 240K tokens | Ultra-long context |
| **DeepSeek** | deepseek-chat, deepseek-coder | 32K tokens | Code-specialized models |
| **Together** | Mixtral, Llama3.1 | 64K-128K tokens | Open source models |

## Usage Examples

### Basic Usage

```python
from jobs.services.ai_manager import ai_manager

# Simple AI call
result = ai_manager.call_model(
    "请生成一个职位描述", 
    'qwen_plus', 
    user,
    json_mode=True
)

if result['success']:
    data = result['data']
    print(f"Generated content: {data}")
else:
    print(f"Error: {result['message']}")
```

### Using High-Level Services

```python
from jobs.services.ai_service import generate_email_draft

# Generate email draft (uses new architecture internally)
result = generate_email_draft(
    keywords="AI工程师招聘",
    job={'title': 'AI工程师', 'company_name': '科技公司'},
    user_name="张三",
    provider_key='kimi_32k',
    user=request.user
)
```

### Error Handling

The new architecture provides comprehensive error handling:

```python
result = ai_manager.call_model(prompt, provider_key, user)

if not result['success']:
    error_type = result['code']
    if error_type == 'auth_error':
        # Handle authentication errors
        print("Please check your API key")
    elif error_type == 'quota_error':
        # Handle quota exceeded
        print("Account quota exceeded")
    elif error_type == 'timeout_error':
        # Handle timeouts
        print("Request timed out, please retry")
```

## Configuration

### Model Configuration (settings.py)

```python
AI_MODELS = {
    'qwen_plus': {
        'name': '通义千问-Plus (推荐)',
        'provider': 'qwen',
        'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
        'model_name': 'qwen-plus'
    },
    'kimi_32k': {
        'name': 'Kimi (32K上下文)',
        'provider': 'kimi', 
        'base_url': 'https://api.moonshot.cn/v1',
        'model_name': 'moonshot-v1-32k'
    },
    # ... more models
}
```

### API Key Management

API keys are stored encrypted in the database using the `ApiKey` model:

```python
from jobs.models import ApiKey

# Users manage their API keys through the admin interface
# The system automatically handles encryption/decryption
```

## Backward Compatibility

The new architecture maintains full backward compatibility:

### Old Code (Still Works)
```python
from jobs.services.parsing_service import _call_ai_model

result = _call_ai_model(prompt, provider_key, user)
```

### New Code (Recommended)
```python
from jobs.services.ai_manager import ai_manager

result = ai_manager.call_model(prompt, provider_key, user)
```

## Adding New Providers

To add support for a new AI provider:

1. **Create an adapter class**:
```python
# jobs/services/ai_adapters/new_provider_adapter.py
from .openai_compatible import OpenAICompatibleAdapter

class NewProviderAdapter(OpenAICompatibleAdapter):
    def get_context_limit(self) -> int:
        return 16384
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        # Provider-specific error handling
        return super().handle_error(error)
```

2. **Register in factory**:
```python
# jobs/services/ai_adapters/adapter_factory.py
ADAPTER_MAPPING = {
    # ... existing mappings
    'new_provider': NewProviderAdapter,
}
```

3. **Add configuration**:
```python
# settings.py
AI_MODELS = {
    # ... existing models
    'new_model': {
        'name': 'New Provider Model',
        'provider': 'new_provider',
        'base_url': 'https://api.newprovider.com/v1',
        'model_name': 'model-name'
    }
}
```

## Testing

Use the management command to test the adapter system:

```bash
# List all available models
python manage.py test_ai_adapters --list-models

# Test a specific provider
python manage.py test_ai_adapters --provider qwen_plus --user admin

# Test with custom prompt
python manage.py test_ai_adapters --test-prompt "Test message" --user admin
```

## Benefits

1. **Modularity**: Each provider has its own adapter with specialized logic
2. **Extensibility**: Easy to add new providers without changing existing code
3. **Error Handling**: Comprehensive, provider-specific error handling
4. **Backward Compatibility**: Existing code continues to work unchanged
5. **Type Safety**: Full type hints for better IDE support and maintainability
6. **Testing**: Isolated testing of each provider
7. **Configuration**: Clean separation of configuration and implementation

## Performance Considerations

- **Adapter Caching**: Adapters are cached to avoid recreation overhead
- **Connection Pooling**: Uses OpenAI client's built-in connection pooling
- **Timeout Handling**: Configurable timeouts for each provider
- **Retry Logic**: Built-in retry logic for transient failures

## Security

- **API Key Encryption**: All API keys are encrypted in the database
- **Access Control**: User-level access control for different models
- **Input Validation**: Comprehensive input validation and sanitization
- **Error Sanitization**: Sensitive information is filtered from error messages