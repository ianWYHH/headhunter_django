# AI Automatic Fallback System

## Overview

The AI Automatic Fallback System provides robust error handling and model switching for AI requests. When the preferred model fails due to quota limits, timeouts, or other issues, the system automatically retries with alternative models, ensuring maximum reliability and user satisfaction.

## Key Features

### 🔄 **Automatic Model Fallback**
- **Smart Model Chain**: Automatically tries preferred model → user fallbacks → system defaults
- **Intelligent Switching**: Switches models based on error type and severity
- **Zero Interruption**: Continues processing even when individual models fail
- **Human-Readable Messages**: Clear, friendly error messages in Chinese

### 🔁 **Intelligent Retry Logic**
- **Transient Error Detection**: Automatically retries timeouts, rate limits, server errors
- **Exponential Backoff**: Smart delay strategies for different error types
- **Retry Limits**: Configurable max retries per model (default: 3)
- **Time Limits**: Total operation timeout protection (default: 5 minutes)

### 📊 **Comprehensive Error Classification**
- **14 Error Types**: From timeout to auth errors to content filtering
- **Provider-Specific**: Tailored error detection for each AI provider
- **Action Suggestions**: Automatic recommendations for error resolution
- **Detailed Logging**: Complete audit trail of all attempts and errors

### 🎯 **Batch Processing Protection**
- **Continue on Failure**: Never stops batch processing for individual failures
- **Failure Isolation**: Each item processed independently with full fallback
- **Retry Batches**: Built-in retry functionality for failed items
- **Progress Tracking**: Real-time progress updates with detailed metrics

## Architecture Components

### Error Classification System

```python
from jobs.services.ai_fallback import ErrorClassifier, ErrorType

classifier = ErrorClassifier()
analysis = classifier.classify_error(error, provider, model)

# Analysis includes:
# - error_type: ErrorType.TIMEOUT, ErrorType.RATE_LIMIT, etc.
# - is_retryable: Whether this error should be retried
# - is_fallback_worthy: Whether to try a different model
# - human_message: "通义千问响应超时"
# - suggested_action: "稍后重试"
# - retry_delay: 2 seconds (with exponential backoff)
```

### Retry Strategy

```python
from jobs.services.ai_fallback import RetryStrategy

strategy = RetryStrategy(max_retries=3, max_total_time=300)
result = strategy.execute_with_retry(func, model_id, provider)

# Automatic handling of:
# - Exponential backoff for rate limits
# - Progressive delays for server errors
# - Time limit enforcement
# - Retry decision logic
```

### Fallback Manager

```python
from jobs.services.ai_fallback import FallbackManager

manager = FallbackManager()
result = manager.execute_with_fallback(
    user=user,
    primary_model='qwen_plus',
    fallback_models=['qwen_turbo', 'kimi_32k', 'deepseek_chat'],
    request_func=lambda model: ai_request(model)
)

# Returns comprehensive FallbackResult with:
# - success: bool
# - final_model: str (which model succeeded)
# - attempts: List[ModelAttempt] (detailed attempt history)
# - human_readable_log: List[str] (user-friendly messages)
```

## Error Types and Handling

### Retryable Errors (Automatic Retry)
| Error Type | Chinese Message | Retry Strategy | Max Retries |
|------------|----------------|----------------|-------------|
| `TIMEOUT` | "{provider} 响应超时" | Progressive delay | 3 |
| `RATE_LIMIT` | "{provider} 请求频率超限" | Exponential backoff | 3 |
| `SERVER_ERROR` | "{provider} 服务器繁忙" | Fixed delay | 3 |
| `NETWORK_ERROR` | "{provider} 网络连接失败" | Progressive delay | 3 |

### Fallback-Worthy Errors (Try Next Model)
| Error Type | Chinese Message | Action |
|------------|----------------|--------|
| `QUOTA_EXCEEDED` | "{provider} 配额不足" | Switch to next model |
| `CONTEXT_TOO_LONG` | "{provider} 请求内容过长" | Try model with larger context |
| `CONTENT_FILTERED` | "{provider} 内容被过滤" | Try different model |
| `MODEL_NOT_FOUND` | "{provider} 模型不存在" | Switch to available model |

### Non-Retryable Errors (Abort or Fallback)
| Error Type | Chinese Message | Action |
|------------|----------------|--------|
| `AUTH_ERROR` | "{provider} API密钥无效" | Skip model, try next |
| `INVALID_REQUEST` | "{provider} 请求格式错误" | Abort (user input issue) |

## Usage Examples

### Basic Fallback Usage

```python
from jobs.services.ai_manager import ai_manager

# Simple fallback call
result = ai_manager.call_model_with_fallback(
    prompt="请解析这个职位信息...",
    user=user,
    primary_model='qwen_plus'  # Will auto-fallback if this fails
)

if result['success']:
    print(f"✓ 成功使用 {result['final_model']} 处理请求")
    if result['fallback_used']:
        print(f"经过 {result['models_tried']} 个模型尝试")
else:
    print(f"✗ 所有模型均失败: {result['message']}")
    # Show user-friendly error log
    for log_entry in result['human_readable_log']:
        print(f"  {log_entry}")
```

### Enhanced Service Integration

```python
# AI Service V2 automatically uses fallback
from jobs.services.ai_service_v2 import generate_email_draft

result = generate_email_draft(
    keywords="AI工程师招聘",
    job={'title': 'AI工程师', 'company_name': '科技公司'},
    user_name="张三",
    provider_key='qwen_plus',  # Will fallback if this fails
    user=request.user
)

# Result includes fallback information
if result.get('fallback_used'):
    messages.info(request, f"使用了备用模型 {result['final_model']}")
```

### Batch Processing with Fallback

```python
from jobs.services.batch_processing import parse_job_batch

# Parse multiple job descriptions
job_texts = [
    "招聘AI工程师，要求熟悉Python...",
    "急招前端开发，React经验...",
    "数据科学家职位，机器学习背景..."
]

result = parse_job_batch(job_texts, user, 'qwen_plus')

print(f"批处理结果: {result.successful_items}/{result.total_items} 成功")
print(f"成功率: {result.success_rate:.1%}")
print(f"总重试次数: {result.total_retries}")
print(f"模型切换次数: {result.total_fallbacks_used}")

# Process results
for item in result.items:
    if item.success:
        print(f"✓ {item.id}: 解析成功")
        if item.fallback_used:
            print(f"  使用了备用模型，尝试了 {item.models_tried} 个模型")
    else:
        print(f"✗ {item.id}: {item.error}")

# Retry failed items
if result.failed_items > 0:
    retry_result = processor.retry_failed_items(result, parse_func)
    print(f"重试后: {retry_result.successful_items}/{retry_result.total_items} 成功")
```

### Custom Fallback Configuration

```python
# Configure user-specific fallback chain
from jobs.services.ai_config import config_manager

preferences = config_manager.get_user_preferences(user)
preferences.preferred_model = 'qwen_plus'
preferences.fallback_models = ['qwen_turbo', 'kimi_32k', 'deepseek_chat']
preferences.max_retries = 5
config_manager.update_user_preferences(user, preferences)

# Use custom fallback chain
result = ai_manager.call_model_with_fallback(
    prompt=prompt,
    user=user,
    # Uses user's configured fallback chain
)
```

## Human-Readable Error Messages

The system provides clear, user-friendly error messages in Chinese:

### Success Messages
```
"尝试使用 通义千问-Plus 处理请求..."
"✅ 通义千问-Plus 成功处理请求"
"❌ 通义千问-Plus 失败: 请求频率超限。正在尝试 Kimi..."
"✅ Kimi 成功处理请求（重试 2 次后成功）"
```

### Fallback Chain Example
```
尝试使用 通义千问-Plus 处理请求...
❌ 通义千问-Plus 失败: 配额不足。正在尝试 通义千问-Turbo...
❌ 通义千问-Turbo 失败: 响应超时。正在尝试 Kimi...
✅ Kimi 成功处理请求
```

### Batch Processing Messages
```
批处理完成: 18/20 成功 (90%)，2 次模型切换
主要错误: timeout(1)、quota_error(1)
```

## Configuration and Settings

### Default Settings

```python
# Retry configuration
AI_RETRY_MAX_ATTEMPTS = 3
AI_RETRY_MAX_TOTAL_TIME = 300  # 5 minutes
AI_RETRY_EXPONENTIAL_BASE = 2

# Error classification
AI_CLASSIFY_PROVIDER_ERRORS = True
AI_ENABLE_HUMAN_MESSAGES = True

# Batch processing
AI_BATCH_CONTINUE_ON_FAILURE = True
AI_BATCH_DEFAULT_RETRY_ATTEMPTS = 1
```

### User Preferences

```python
# Per-user configuration
preferences = UserPreferences(
    preferred_model='qwen_plus',
    fallback_models=['qwen_turbo', 'kimi_32k', 'deepseek_chat'],
    max_retries=3,
    max_tokens_per_request=2000,
    timeout_override=120
)
```

## Performance Metrics

### Fallback Performance

```python
# Get detailed performance metrics
result = ai_manager.call_model_with_fallback(prompt, user)
metrics = {
    'execution_time': result['execution_time'],
    'models_tried': result['models_tried'],
    'total_retries': result['total_retries'],
    'fallback_used': result['fallback_used'],
    'final_model': result['final_model']
}

# Typical performance
# - Single model success: 1-3 seconds
# - With 1 fallback: 3-8 seconds  
# - With 2 fallbacks: 5-15 seconds
# - Max time limit: 300 seconds
```

### Batch Processing Metrics

```python
batch_result = parse_job_batch(job_texts, user)
print(f"平均处理时间: {batch_result.average_execution_time:.2f}s")
print(f"总模型尝试: {batch_result.total_models_tried}")
print(f"成功率: {batch_result.success_rate:.1%}")

# Error distribution
for error_type, count in batch_result.error_summary.items():
    print(f"{error_type}: {count}")
```

## Testing and Monitoring

### Test Commands

```bash
# Test basic fallback functionality
python manage.py test_ai_fallback --user admin --primary-model qwen_plus

# Test with custom fallback chain
python manage.py test_ai_fallback --user admin --primary-model qwen_plus \
    --fallback-models qwen_turbo kimi_32k deepseek_chat

# Test batch processing
python manage.py test_ai_fallback --user admin --batch-test --show-logs

# Show detailed execution logs
python manage.py test_ai_fallback --user admin --show-logs
```

### Monitoring Fallback Health

```python
# Check user's fallback configuration
status = ai_manager.get_fallback_status(user)

print(f"主要模型: {status['primary_model']}")
print(f"可用模型: {status['accessible_models']}")
print(f"回退健康度: {status['fallback_health']}")

if status['recommendations']:
    print("建议:")
    for rec in status['recommendations']:
        print(f"  - {rec}")

# Fallback health levels:
# - "healthy": 2+ accessible models
# - "limited": 1 accessible model  
# - "none": 0 accessible models
```

### Logging and Debugging

```python
import logging

# Enable detailed fallback logging
logging.getLogger('jobs.services.ai_fallback').setLevel(logging.DEBUG)

# Log includes:
# - Model selection decisions
# - Retry attempts and delays
# - Error classifications
# - Fallback triggers
# - Performance metrics
```

## Integration Examples

### View Integration

```python
def parse_job_view(request):
    job_text = request.POST.get('job_text')
    
    # Parse with automatic fallback
    result = ai_manager.call_model_with_fallback(
        prompt=f"请解析职位信息: {job_text}",
        user=request.user,
        json_mode=True
    )
    
    if result['success']:
        # Show success message with model info
        if result['fallback_used']:
            messages.info(request, 
                f"解析成功！使用了 {result['final_model']} "
                f"（尝试了 {result['models_tried']} 个模型）")
        else:
            messages.success(request, "解析成功！")
        
        return JsonResponse({'success': True, 'data': result['data']})
    else:
        # Show user-friendly error messages
        error_messages = "\n".join(result['human_readable_log'])
        messages.error(request, f"解析失败：{error_messages}")
        
        return JsonResponse({
            'success': False, 
            'error': result['message'],
            'details': result['human_readable_log']
        })
```

### Form Integration

```python
class JobParseForm(forms.Form):
    job_text = forms.CharField(widget=forms.Textarea)
    
    def parse_with_fallback(self, user):
        job_text = self.cleaned_data['job_text']
        
        # Use batch processing for multiple jobs
        if '\n---\n' in job_text:  # Multiple jobs separated
            job_list = job_text.split('\n---\n')
            batch_result = parse_job_batch(job_list, user)
            
            return {
                'success': batch_result.success_rate > 0.5,  # 50% success threshold
                'results': [item.result for item in batch_result.items if item.success],
                'summary': f"{batch_result.successful_items}/{batch_result.total_items} 解析成功",
                'errors': [item.error for item in batch_result.items if not item.success]
            }
        else:
            # Single job with fallback
            result = ai_manager.call_model_with_fallback(
                prompt=f"解析职位: {job_text}",
                user=user,
                json_mode=True
            )
            
            return result
```

## Best Practices

### 1. Always Use Fallback for User-Facing Features
```python
# ✅ Good: Use fallback for user requests
result = ai_manager.call_model_with_fallback(prompt, user)

# ❌ Bad: Direct model calls for user features
result = ai_manager.call_model(prompt, 'qwen_plus', user)
```

### 2. Configure Appropriate Fallback Chains
```python
# ✅ Good: Diverse provider fallback chain
fallback_models = ['qwen_plus', 'kimi_32k', 'deepseek_chat']  # Different providers

# ❌ Bad: Single provider fallback
fallback_models = ['qwen_plus', 'qwen_turbo', 'qwen_max']  # Same provider
```

### 3. Handle Batch Processing Failures Gracefully
```python
# ✅ Good: Continue processing and retry failures
processor = BatchProcessor(user, continue_on_failure=True)
result = processor.process_batch(items, process_func)

if result.failed_items > 0:
    retry_result = processor.retry_failed_items(result, process_func)

# ❌ Bad: Stop on first failure
processor = BatchProcessor(user, continue_on_failure=False)
```

### 4. Show User-Friendly Messages
```python
# ✅ Good: Show fallback information to users
if result['fallback_used']:
    messages.info(request, f"使用了备用模型 {result['final_model']}")

# Display human-readable logs
for log_entry in result['human_readable_log']:
    messages.info(request, log_entry)
```

### 5. Monitor and Optimize Fallback Performance
```python
# ✅ Good: Track fallback usage patterns
metrics = {
    'fallback_rate': result['fallback_used'],
    'avg_models_tried': result['models_tried'],
    'success_rate': 1.0 if result['success'] else 0.0
}

# Use metrics to optimize model selection and fallback chains
```

## Troubleshooting

### Common Issues

1. **High Fallback Rate**
   ```python
   # Check quota and rate limits
   status = ai_manager.get_fallback_status(user)
   print(status['recommendations'])
   ```

2. **Slow Fallback Performance**
   ```python
   # Reduce retry attempts or timeout
   preferences.max_retries = 2
   preferences.timeout_override = 60
   ```

3. **All Models Failing**
   ```python
   # Check API key configuration
   python manage.py manage_ai_models list --user username
   ```

4. **Batch Processing Stuck**
   ```python
   # Enable continue_on_failure
   processor = BatchProcessor(user, continue_on_failure=True)
   ```

The AI Automatic Fallback System ensures maximum reliability and user satisfaction by intelligently handling AI model failures and providing seamless fallback capabilities with clear, actionable feedback.