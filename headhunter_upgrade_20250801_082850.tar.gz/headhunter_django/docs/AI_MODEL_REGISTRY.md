# AI Model Registry & Configuration System

## Overview

The AI Model Registry provides a centralized, flexible configuration system for managing AI models, user preferences, and system settings. It replaces the simple `AI_MODELS` dictionary with a comprehensive configuration framework.

## Key Features

### 🎯 **Centralized Model Registry**
- **Comprehensive Model Definitions**: Each model includes name, provider, context limits, rate limits, costs, capabilities, and more
- **Multiple Configuration Sources**: Support for Django settings, JSON files, and programmatic configuration
- **Intelligent Defaults**: Automatic fallback and intelligent estimation for missing configuration
- **Validation & Migration**: Built-in validation and legacy configuration migration

### 👤 **User Preferences Management**
- **Individual Preferences**: Each user can set preferred models, fallback chains, retry limits
- **Access Control**: Automatic validation based on user's available API keys
- **Intelligent Model Selection**: Automatic model selection with fallback logic
- **Performance Tuning**: User-specific timeout, token, and temperature overrides

### 📊 **Advanced Configuration Options**
- **Rate Limiting**: Provider-specific and user-specific rate limits
- **Cost Tracking**: Input/output token costs for budget management
- **Capability Flags**: JSON mode, streaming, function calling support
- **Status Management**: Active/deprecated status with replacement suggestions

## Configuration Structure

### Model Configuration (`ModelConfig`)

```python
@dataclass
class ModelConfig:
    # Basic Information
    model_id: str                    # Unique identifier
    name: str                        # Display name
    provider: str                    # Provider (qwen, kimi, etc.)
    model_name: str                  # API model name
    base_url: str                    # API endpoint
    
    # Capabilities
    max_context_tokens: int          # Context window size
    supports_json_mode: bool         # JSON response support
    supports_streaming: bool         # Streaming support
    supports_function_calling: bool  # Function calling support
    
    # Performance & Limits
    rate_limits: RateLimits         # Rate limiting configuration
    default_temperature: float      # Default temperature
    timeout_seconds: int            # Request timeout
    
    # Cost Information
    cost_per_1k_input_tokens: float   # Input cost per 1K tokens
    cost_per_1k_output_tokens: float  # Output cost per 1K tokens
    
    # Metadata
    description: str                 # Model description
    tags: List[str]                 # Classification tags
    is_active: bool                 # Active status
    is_deprecated: bool             # Deprecation status
```

### User Preferences (`UserPreferences`)

```python
@dataclass
class UserPreferences:
    user_id: int                    # User ID
    preferred_model: str            # Preferred model ID
    fallback_models: List[str]      # Fallback model IDs (in order)
    max_retries: int               # Maximum retry attempts
    max_tokens_per_request: int    # Token limit per request
    default_temperature: float     # Default temperature override
    timeout_override: int          # Timeout override
```

## Configuration Sources

### 1. Django Settings (Enhanced)

Create `settings_ai_models.py`:

```python
AI_MODEL_CONFIGS = {
    'qwen_plus': {
        'name': '通义千问-Plus (推荐)',
        'provider': 'qwen',
        'model_name': 'qwen-plus',
        'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
        'max_context_tokens': 32768,
        'supports_json_mode': True,
        'rate_limits': {
            'requests_per_minute': 60,
            'tokens_per_minute': 100000,
            'requests_per_day': 1000,
            'concurrent_requests': 5
        },
        'cost_per_1k_input_tokens': 0.008,
        'cost_per_1k_output_tokens': 0.02,
        'adapter_class': 'QwenAdapter',
        'tags': ['recommended', 'balanced', 'chinese'],
        'is_active': True
    }
}

# Default User Preferences
AI_DEFAULT_MODEL = 'qwen_plus'
AI_DEFAULT_FALLBACK_MODELS = ['qwen_plus', 'qwen_turbo', 'kimi_32k']
AI_DEFAULT_MAX_RETRIES = 3
```

### 2. JSON Configuration File

Store in `config/ai_models.json`:

```json
{
  "version": "1.0",
  "models": {
    "qwen_plus": {
      "name": "通义千问-Plus (推荐)",
      "provider": "qwen",
      "model_name": "qwen-plus",
      "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
      "max_context_tokens": 32768,
      "rate_limits": {
        "requests_per_minute": 60,
        "tokens_per_minute": 100000
      },
      "tags": ["recommended", "chinese"]
    }
  },
  "default_preferences": {
    "preferred_model": "qwen_plus",
    "fallback_models": ["qwen_plus", "qwen_turbo"]
  }
}
```

## Usage Examples

### Basic Model Registry Usage

```python
from jobs.services.ai_config import model_registry

# Load configurations
model_registry.ensure_loaded()

# Get model configuration
qwen_config = model_registry.get_model('qwen_plus')
print(f"Context limit: {qwen_config.max_context_tokens}")

# Get models by provider
qwen_models = model_registry.get_models_by_provider('qwen')

# Search models
ai_models = model_registry.search_models('AI')

# Get active models only
active_models = model_registry.get_active_models()
```

### Configuration Manager Usage

```python
from jobs.services.ai_config import config_manager

# Get user preferences
preferences = config_manager.get_user_preferences(user)

# Get user's available models
user_models = config_manager.get_available_models_for_user(user)

# Select best model for user
selected_model = config_manager.select_model_for_user(user, 'qwen_plus')

# Update user preferences
preferences.preferred_model = 'kimi_32k'
preferences.fallback_models = ['kimi_32k', 'qwen_plus']
config_manager.update_user_preferences(user, preferences)

# Get model with user preferences applied
model_config = config_manager.get_model_with_preferences(user, 'qwen_plus')
```

### Enhanced AI Manager Integration

```python
from jobs.services.ai_manager import ai_manager

# The AI manager now automatically uses the new configuration system
result = ai_manager.call_model(prompt, 'qwen_plus', user)

# Check user access (uses new validation)
access = ai_manager.check_user_access(user, 'kimi_32k')

# Get user's available models (filtered by API keys)
models = ai_manager.get_user_available_models(user)
```

## Management Commands

### Model Management

```bash
# List all models
python manage.py manage_ai_models list

# List active models only
python manage.py manage_ai_models list --active-only

# List models for specific user
python manage.py manage_ai_models list --user admin

# Show detailed model information
python manage.py manage_ai_models show qwen_plus

# Test model configuration
python manage.py manage_ai_models test qwen_plus --user admin

# Validate all configurations
python manage.py manage_ai_models validate

# Export configurations
python manage.py manage_ai_models export --output config/models.json
python manage.py manage_ai_models export --format settings --output settings_models.py

# Import configurations
python manage.py manage_ai_models import config/models.json

# System statistics
python manage.py manage_ai_models stats
```

### User Preferences Management

```bash
# Show user preferences
python manage.py manage_ai_models preferences admin --show

# Set preferred model
python manage.py manage_ai_models preferences admin --preferred-model kimi_32k

# Set fallback models
python manage.py manage_ai_models preferences admin --fallback-models qwen_plus qwen_turbo kimi_32k

# Set max retries
python manage.py manage_ai_models preferences admin --max-retries 5
```

### Legacy Configuration Migration

```bash
# Convert legacy AI_MODELS to new format
python manage.py import_legacy_config

# Export to JSON
python manage.py import_legacy_config --output config/converted_models.json

# Export to settings format
python manage.py import_legacy_config --settings-output settings_converted.py

# Preview conversion without writing files
python manage.py import_legacy_config --dry-run
```

## Provider-Specific Features

### Rate Limiting Configuration

```python
rate_limits = RateLimits(
    requests_per_minute=60,
    tokens_per_minute=100000,
    requests_per_day=1000,
    concurrent_requests=5
)
```

### Cost Tracking

```python
# Estimate costs
input_cost = tokens * (model.cost_per_1k_input_tokens / 1000)
output_cost = tokens * (model.cost_per_1k_output_tokens / 1000)
total_cost = input_cost + output_cost
```

### Capability Detection

```python
if model.supports_json_mode:
    request_params['response_format'] = {"type": "json_object"}

if model.supports_streaming:
    request_params['stream'] = True

if model.supports_function_calling:
    request_params['tools'] = function_definitions
```

## Advanced Features

### Model Selection Logic

1. **Requested Model**: Use if available and user has access
2. **User Preferred**: Fall back to user's preferred model
3. **Fallback Chain**: Try user's fallback models in order
4. **System Default**: Use system default as last resort

### Intelligent Fallback

```python
# Get complete fallback chain
chain = config_manager.get_fallback_chain(user, 'qwen_plus')
# Result: ['qwen_plus', 'qwen_turbo', 'kimi_32k', 'deepseek_chat']

# Try each model in chain
for model_id in chain:
    if config_manager.validate_user_model_access(user, model_id)['has_access']:
        selected_model = model_id
        break
```

### Configuration Validation

```python
# Validate all model configurations
errors = model_registry.validate_all_models()

if errors:
    for model_id, model_errors in errors.items():
        print(f"Errors in {model_id}: {model_errors}")
```

## Migration from Legacy System

### Backward Compatibility

The new system maintains 100% backward compatibility:

```python
# Old code continues to work
from jobs.services.parsing_service import _call_ai_model
result = _call_ai_model(prompt, 'qwen_plus', user)

# New code uses enhanced features
from jobs.services.ai_manager import ai_manager
result = ai_manager.call_model(prompt, 'qwen_plus', user)
```

### Migration Steps

1. **Install New System**: Deploy new configuration files
2. **Import Legacy**: Run `python manage.py import_legacy_config`
3. **Validate**: Run `python manage.py manage_ai_models validate`
4. **Test**: Run `python manage.py manage_ai_models test qwen_plus`
5. **Update Settings**: Replace `AI_MODELS` with `AI_MODEL_CONFIGS`

### Configuration File Locations

```
config/
├── ai_models.json              # Main JSON configuration
└── ai_models_backup.json       # Backup configuration

headhunter_django/
└── settings_ai_models.py       # Django settings format
```

## Performance Considerations

### Caching Strategy

- **Model Registry**: Loaded once and cached in memory
- **User Preferences**: Cached for 5 minutes (configurable)
- **Access Validation**: Results cached per user session

### Memory Usage

- **Model Configs**: ~1KB per model configuration
- **User Preferences**: ~100 bytes per user
- **Total Overhead**: <100KB for typical deployments

### Database Impact

- **No Additional Tables**: Uses existing `ApiKey` model
- **Query Optimization**: Minimal additional database queries
- **Future Enhancement**: Optional `UserAIPreferences` model for persistence

## Security & Access Control

### API Key Security

- **Encryption**: All API keys remain encrypted in database
- **Access Control**: Model access based on user's API key availability
- **Validation**: Real-time validation of user permissions

### Configuration Security

- **Input Validation**: All configuration inputs validated
- **Error Sanitization**: Sensitive information filtered from errors
- **Audit Trail**: Configuration changes logged

## Troubleshooting

### Common Issues

1. **Configuration Not Loading**:
   ```bash
   python manage.py manage_ai_models validate
   ```

2. **User Access Denied**:
   ```bash
   python manage.py manage_ai_models list --user username
   ```

3. **Legacy Migration Issues**:
   ```bash
   python manage.py import_legacy_config --dry-run
   ```

### Debug Commands

```bash
# Check model registry status
python manage.py manage_ai_models stats

# Test specific model
python manage.py manage_ai_models test model_id --user username

# Validate all configurations
python manage.py manage_ai_models validate

# Clear cache
python manage.py shell -c "from jobs.services.ai_config import config_manager; config_manager.clear_all_cache()"
```

The AI Model Registry provides a powerful, flexible foundation for managing AI model configurations while maintaining backward compatibility and enabling future enhancements.