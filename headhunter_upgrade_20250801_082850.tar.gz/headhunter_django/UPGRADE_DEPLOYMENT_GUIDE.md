# 智能猎头招聘管理系统 - 升级部署指南

## 目录
1. [升级前准备](#升级前准备)
2. [数据备份](#数据备份)
3. [代码升级](#代码升级)
4. [环境依赖更新](#环境依赖更新)
5. [配置文件更新](#配置文件更新)
6. [数据库迁移](#数据库迁移)
7. [新功能配置](#新功能配置)
8. [服务重启](#服务重启)
9. [升级验证](#升级验证)
10. [回滚方案](#回滚方案)
11. [故障排除](#故障排除)

---

## 升级前准备

### 1. 系统环境检查
```bash
# 检查Python版本（需要3.8+）
python3 --version

# 检查当前项目版本
cd /www/wwwroot/your_project_name
git log --oneline -5

# 检查磁盘空间
df -h

# 检查内存使用情况
free -m
```

### 2. 升级时间规划
- **建议升级时间**: 业务低峰期（如凌晨2-6点）
- **预计升级时长**: 30-60分钟
- **回滚时间**: 10-20分钟（如需要）

### 3. 通知相关人员
- [ ] 通知系统用户暂停使用
- [ ] 准备技术支持团队
- [ ] 制定应急联系方式

---

## 数据备份

### 1. 数据库备份（关键步骤）

#### 通过堡塔面板备份
1. 登录堡塔面板
2. 进入 **数据库** 管理
3. 找到项目数据库，点击 **备份**
4. 选择备份类型为 **完整备份**
5. 等待备份完成，下载备份文件到本地

#### 命令行备份（备选方案）
```bash
# 创建备份目录
mkdir -p /www/backup/$(date +%Y%m%d_%H%M%S)
cd /www/backup/$(date +%Y%m%d_%H%M%S)

# 备份数据库（需要RDS连接信息）
mysqldump -h your_rds_host \
  -P 3306 \
  -u your_username \
  -p your_database_name \
  --single-transaction \
  --routines \
  --triggers > headhunter_backup_$(date +%Y%m%d_%H%M%S).sql
```

### 2. 代码备份
```bash
# 备份当前项目代码
cd /www/wwwroot
tar -czf headhunter_backup_$(date +%Y%m%d_%H%M%S).tar.gz your_project_name/

# 移动备份文件到备份目录
mv *.tar.gz /www/backup/$(date +%Y%m%d_%H%M%S)/
```

### 3. 配置文件备份
```bash
# 备份重要配置文件
cp /www/wwwroot/your_project_name/.env /www/backup/$(date +%Y%m%d_%H%M%S)/
cp /www/wwwroot/your_project_name/headhunter_django/settings.py /www/backup/$(date +%Y%m%d_%H%M%S)/
```

---

## 代码升级

### 1. 获取最新代码

#### 方式一：Git拉取（推荐）
```bash
cd /www/wwwroot/your_project_name

# 停止应用服务
# 在堡塔面板中停止Python项目

# 拉取最新代码
git stash  # 暂存本地修改
git pull origin main  # 或者你的主分支名
git stash pop  # 恢复本地修改（如有冲突需手动解决）
```

#### 方式二：文件替换
如果没有使用Git，需要手动上传新代码：
1. 将本地最新代码打包上传到服务器
2. 解压到临时目录
3. 复制新文件，保留配置文件

```bash
# 创建临时目录
mkdir /tmp/headhunter_new

# 解压新代码（假设已上传到/tmp）
cd /tmp
tar -xzf headhunter_latest.tar.gz -C headhunter_new/

# 备份配置文件
cp /www/wwwroot/your_project_name/.env /tmp/
cp /www/wwwroot/your_project_name/headhunter_django/settings.py /tmp/

# 替换代码（保留配置）
cd /www/wwwroot/your_project_name
rm -rf jobs/ headhunter_django/ static/ templates/ manage.py requirements.txt
cp -r /tmp/headhunter_new/* .

# 恢复配置文件
cp /tmp/.env .
cp /tmp/settings.py headhunter_django/
```

### 2. 文件权限设置
```bash
cd /www/wwwroot/your_project_name

# 设置正确的文件权限
chown -R www:www .
chmod -R 755 .
chmod 644 requirements.txt
chmod 755 manage.py
```

---

## 环境依赖更新

### 1. 激活虚拟环境
```bash
# 通过堡塔面板或命令行激活虚拟环境
cd /www/wwwroot/your_project_name
source venv/bin/activate  # 或者你的虚拟环境路径
```

### 2. 更新Python依赖
```bash
# 更新pip
pip install --upgrade pip

# 安装新依赖
pip install -r requirements.txt

# 验证关键包是否安装成功
pip list | grep -E "(django|APScheduler|cryptography)"
```

### 3. 新增依赖说明
以下是本次升级新增的关键依赖：
- `APScheduler==3.10.4` - 定时任务调度
- `pytz` - 时区处理
- `cryptography` - 数据加密

如果安装失败，请尝试：
```bash
# 清理pip缓存
pip cache purge

# 单独安装问题包
pip install APScheduler==3.10.4
pip install cryptography
pip install pytz
```

---

## 配置文件更新

### 1. 环境变量更新
检查并更新 `.env` 文件：

```bash
cd /www/wwwroot/your_project_name
nano .env  # 或使用堡塔面板文件管理器编辑
```

确保包含以下新配置项：
```env
# 原有配置保持不变...

# 新增配置项（如果没有请添加）
ENCRYPTION_KEY=your-encryption-key-here
EMAIL_USE_TLS=True
EMAIL_USE_SSL=False

# 时区设置
TIME_ZONE=Asia/Shanghai
```

### 2. 生成加密密钥
```bash
cd /www/wwwroot/your_project_name
python3 generate_key.py
```
将输出的密钥添加到 `.env` 文件的 `ENCRYPTION_KEY` 项中。

### 3. Django设置检查
确认 `headhunter_django/settings.py` 中的新配置：

```python
# 时区设置
TIME_ZONE = 'Asia/Shanghai'
USE_TZ = True

# 应用列表（确保包含新应用）
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'jobs',
    'django_htmx',
    'widget_tweaks',
]

# 中间件（确保包含HTMX中间件）
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django_htmx.middleware.HtmxMiddleware',
]
```

---

## 数据库迁移

### 1. 检查迁移文件
```bash
cd /www/wwwroot/your_project_name
python3 manage.py showmigrations
```

### 2. 创建新迁移
```bash
# 创建迁移文件
python3 manage.py makemigrations

# 检查迁移计划
python3 manage.py showmigrations
```

### 3. 执行数据库迁移
```bash
# 执行迁移（谨慎操作）
python3 manage.py migrate

# 如果出现冲突，可能需要假应用某些迁移
# python3 manage.py migrate --fake-initial
```

### 4. 验证数据库结构
```bash
# 连接数据库检查新表
python3 manage.py dbshell

# 在MySQL中检查新增的表和字段
SHOW TABLES;
DESC jobs_emailaccountstats;  # 检查新表结构
DESC jobs_incomingemail;      # 检查新表结构
DESC jobs_scheduledemaultask; # 检查新表结构
exit;
```

---

## 新功能配置

### 1. AI服务配置
新版本引入了AI管理器架构，需要配置：

```bash
# 检查AI配置文件
ls -la jobs/services/ai_adapters/
ls -la jobs/services/ai_config/
ls -la jobs/services/ai_fallback/
```

### 2. 静态文件收集
```bash
cd /www/wwwroot/your_project_name
python3 manage.py collectstatic --noinput
```

### 3. 创建超级用户（如需要）
```bash
python3 manage.py createsuperuser
```

---

## 服务重启

### 1. 通过堡塔面板重启

#### Python项目重启
1. 登录堡塔面板
2. 进入 **网站** 管理
3. 找到项目，点击 **设置**
4. 在Python项目管理中点击 **重启**

#### Nginx重启
1. 在堡塔面板进入 **软件商店**
2. 找到Nginx，点击 **重启**

### 2. 命令行重启（备选）
```bash
# 重启Python应用（具体方式取决于部署方式）
systemctl restart gunicorn  # 如果使用systemd
# 或
supervisorctl restart your_project_name  # 如果使用supervisor

# 重启Nginx
systemctl restart nginx
```

### 3. 验证服务状态
```bash
# 检查Python进程
ps aux | grep python

# 检查端口监听
netstat -tlnp | grep :8000

# 检查Nginx状态
systemctl status nginx
```

---

## 升级验证

### 1. 基本功能测试
1. 访问网站首页：`http://your-domain.com`
2. 测试登录功能
3. 检查主要功能模块：
   - 职位管理
   - 候选人管理
   - 邮件功能
   - AI解析功能

### 2. 新功能测试
1. **SMTP状态检查**
   - 进入邮箱账户管理页面
   - 检查SMTP连接状态显示

2. **AI服务测试**
   - 测试AI解析功能
   - 检查AI模型切换

3. **批处理功能测试**
   - 上传大批量数据
   - 观察处理进度

### 3. 日志检查
```bash
# 检查Django日志
tail -f /www/wwwroot/your_project_name/logs/django.log

# 检查Nginx日志
tail -f /www/nginx/logs/access.log
tail -f /www/nginx/logs/error.log

# 检查堡塔面板日志
tail -f /www/server/panel/logs/error.log
```

### 4. 性能测试
```bash
# 检查内存使用
free -m

# 检查磁盘使用
df -h

# 检查进程资源使用
top -p $(pgrep python)
```

---

## 回滚方案

如果升级出现问题，可以快速回滚：

### 1. 代码回滚
```bash
cd /www/wwwroot/your_project_name

# Git回滚
git reset --hard HEAD~1  # 回滚到上一个版本

# 或者恢复备份
rm -rf *
tar -xzf /www/backup/20241201_020000/headhunter_backup_20241201_020000.tar.gz
```

### 2. 数据库回滚
```bash
# 停止应用
# 通过堡塔面板停止Python项目

# 恢复数据库备份
mysql -h your_rds_host -P 3306 -u your_username -p your_database_name < /www/backup/20241201_020000/headhunter_backup_20241201_020000.sql
```

### 3. 配置回滚
```bash
cp /www/backup/20241201_020000/.env /www/wwwroot/your_project_name/
cp /www/backup/20241201_020000/settings.py /www/wwwroot/your_project_name/headhunter_django/
```

### 4. 重启服务
按照 [服务重启](#服务重启) 章节的步骤重启服务。

---

## 故障排除

### 1. 常见问题及解决方案

#### 问题1：依赖包安装失败
```bash
# 解决方案
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt --no-cache-dir
```

#### 问题2：数据库连接失败
```bash
# 检查数据库配置
cat .env | grep DB_

# 测试数据库连接
python3 manage.py dbshell
```

#### 问题3：静态文件404
```bash
# 重新收集静态文件
python3 manage.py collectstatic --clear --noinput

# 检查Nginx配置
nginx -t
```

#### 问题4：AI服务调用失败
```bash
# 检查API密钥配置
python3 manage.py shell
>>> from jobs.models import ApiKey
>>> ApiKey.objects.all()
```

#### 问题5：定时任务不工作
```bash
# 检查APScheduler是否启动
ps aux | grep python | grep manage.py

# 检查日志
tail -f logs/scheduler.log
```

### 2. 日志级别调整
如需详细调试信息，在 `settings.py` 中设置：

```python
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'file': {
            'level': 'DEBUG',  # 改为DEBUG级别
            'class': 'logging.FileHandler',
            'filename': 'logs/django.log',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'DEBUG',
            'propagate': True,
        },
    },
}
```

### 3. 紧急联系方式
- 技术支持：[联系方式]
- 系统管理员：[联系方式]
- 阿里云技术支持：95187

---

## 升级后维护建议

### 1. 定期备份
- 设置自动数据库备份（每日）
- 设置代码备份（每周）
- 监控磁盘空间使用

### 2. 性能监控
- 监控系统资源使用
- 监控AI服务调用频率
- 监控邮件发送量

### 3. 安全加固
- 定期更新系统补丁
- 检查防火墙规则
- 监控异常访问

### 4. 功能优化
- 根据使用情况调整AI模型配置
- 优化邮箱发送策略
- 调整定时任务频率

---

## 升级检查清单

升级完成后，请逐项检查：

- [ ] 数据库备份完成
- [ ] 代码备份完成
- [ ] 依赖包更新成功
- [ ] 数据库迁移完成
- [ ] 配置文件更新
- [ ] 静态文件收集
- [ ] 服务重启成功
- [ ] 网站访问正常
- [ ] 登录功能正常
- [ ] 主要功能测试通过
- [ ] 新功能验证完成
- [ ] 日志记录正常
- [ ] 性能指标正常

---

**升级完成时间**: ___________  
**升级执行人**: ___________  
**升级结果**: ___________  
**备注**: ___________