# 服务器安装说明

## 文件说明

本压缩包包含智能猎头招聘管理系统的最新版本，专门用于服务器部署升级。

### 📁 文件结构
```
headhunter_django/
├── jobs/                           # 主应用代码
├── headhunter_django/              # Django项目配置
├── static/                         # 静态文件
├── docs/                           # 项目文档
├── manage.py                       # Django管理脚本
├── requirements.txt                # Python依赖包
├── generate_key.py                 # 加密密钥生成工具
├── env_example.txt                 # 环境变量示例
├── env_server_template.txt         # 服务器环境配置模板
├── upgrade_script.sh               # 自动升级脚本
├── pre_upgrade_check.sh            # 升级前检查脚本
├── UPGRADE_DEPLOYMENT_GUIDE.md     # 详细升级指南
├── QUICK_UPGRADE_GUIDE.md          # 快速升级指南
├── BT_PANEL_OPERATIONS.md          # 堡塔面板操作指南
└── UPGRADE_DOCS_INDEX.md           # 文档索引
```

## 🚀 快速开始

### 1. 上传文件
将解压后的 `headhunter_django` 文件夹上传到服务器的 `/www/wwwroot/` 目录

### 2. 配置环境变量
```bash
cd /www/wwwroot/headhunter_django
cp env_server_template.txt .env
nano .env  # 编辑配置文件
```

### 3. 生成加密密钥
```bash
python3 generate_key.py
# 将输出的密钥添加到 .env 文件的 ENCRYPTION_KEY 项
```

### 4. 运行升级前检查
```bash
bash pre_upgrade_check.sh
```

### 5. 执行自动升级
```bash
bash upgrade_script.sh
```

## ⚠️ 重要提醒

1. **备份数据**：升级前务必备份数据库和现有项目文件
2. **环境配置**：.env文件需要根据服务器实际环境配置
3. **权限设置**：确保文件权限正确（www:www, 755）
4. **依赖安装**：需要Python 3.8+和相关依赖包

## 📖 详细文档

请参考以下文档获取详细信息：
- `UPGRADE_DOCS_INDEX.md` - 文档索引
- `QUICK_UPGRADE_GUIDE.md` - 快速升级指南  
- `UPGRADE_DEPLOYMENT_GUIDE.md` - 完整升级文档
- `BT_PANEL_OPERATIONS.md` - 堡塔面板操作指南

## 📞 技术支持

如遇问题请参考故障排除文档或联系技术支持。
