#!/bin/bash

# 智能猎头招聘管理系统 - 自动化升级脚本
# 使用方法: bash upgrade_script.sh [project_path]
# 示例: bash upgrade_script.sh /www/wwwroot/headhunter

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查参数
PROJECT_PATH=${1:-"/www/wwwroot/headhunter"}
BACKUP_DIR="/www/backup/$(date +%Y%m%d_%H%M%S)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

log_info "开始升级智能猎头招聘管理系统..."
log_info "项目路径: $PROJECT_PATH"
log_info "备份目录: $BACKUP_DIR"

# 检查项目路径是否存在
if [ ! -d "$PROJECT_PATH" ]; then
    log_error "项目路径不存在: $PROJECT_PATH"
    exit 1
fi

# 创建备份目录
mkdir -p "$BACKUP_DIR"
log_success "创建备份目录: $BACKUP_DIR"

# 1. 系统检查
log_info "1. 进行系统检查..."

# 检查Python版本
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
log_info "Python版本: $PYTHON_VERSION"

# 检查磁盘空间
DISK_USAGE=$(df -h $PROJECT_PATH | awk 'NR==2 {print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -gt 85 ]; then
    log_warning "磁盘使用率较高: ${DISK_USAGE}%"
    read -p "是否继续? (y/N): " confirm
    if [[ $confirm != [yY] ]]; then
        log_error "用户取消升级"
        exit 1
    fi
fi

# 检查内存使用
MEMORY_USAGE=$(free | awk 'FNR==2{printf "%.2f", $3/($3+$4)*100}')
log_info "内存使用率: ${MEMORY_USAGE}%"

# 2. 备份当前系统
log_info "2. 开始备份当前系统..."

# 备份代码
cd "$(dirname "$PROJECT_PATH")"
PROJECT_NAME=$(basename "$PROJECT_PATH")
tar -czf "$BACKUP_DIR/code_backup.tar.gz" "$PROJECT_NAME/"
log_success "代码备份完成"

# 备份配置文件
if [ -f "$PROJECT_PATH/.env" ]; then
    cp "$PROJECT_PATH/.env" "$BACKUP_DIR/"
    log_success "环境配置备份完成"
fi

if [ -f "$PROJECT_PATH/headhunter_django/settings.py" ]; then
    cp "$PROJECT_PATH/headhunter_django/settings.py" "$BACKUP_DIR/"
    log_success "Django配置备份完成"
fi

# 3. 数据库备份提醒
log_warning "请确保已通过堡塔面板完成数据库备份！"
read -p "数据库备份是否已完成? (y/N): " db_backup_confirm
if [[ $db_backup_confirm != [yY] ]]; then
    log_error "请先完成数据库备份，然后重新运行升级脚本"
    exit 1
fi

# 4. 停止服务提醒
log_warning "请通过堡塔面板停止Python项目！"
read -p "Python项目是否已停止? (y/N): " service_stop_confirm
if [[ $service_stop_confirm != [yY] ]]; then
    log_error "请先停止Python项目，然后重新运行升级脚本"
    exit 1
fi

# 5. 更新代码
log_info "3. 更新项目代码..."
cd "$PROJECT_PATH"

if [ -d ".git" ]; then
    log_info "检测到Git仓库，使用Git更新代码"
    # 暂存本地修改
    git stash
    # 拉取最新代码
    git pull origin main || git pull origin master
    # 恢复本地修改
    git stash pop || log_warning "本地修改恢复失败，请手动检查"
    log_success "Git代码更新完成"
else
    log_warning "未检测到Git仓库，请手动更新代码文件"
    read -p "代码文件是否已手动更新? (y/N): " code_update_confirm
    if [[ $code_update_confirm != [yY] ]]; then
        log_error "请先更新代码文件"
        exit 1
    fi
fi

# 6. 设置文件权限
log_info "4. 设置文件权限..."
chown -R www:www "$PROJECT_PATH"
chmod -R 755 "$PROJECT_PATH"
chmod 644 "$PROJECT_PATH/requirements.txt"
chmod 755 "$PROJECT_PATH/manage.py"
log_success "文件权限设置完成"

# 7. 激活虚拟环境并更新依赖
log_info "5. 更新Python依赖..."

# 查找虚拟环境
VENV_PATH=""
if [ -d "$PROJECT_PATH/venv" ]; then
    VENV_PATH="$PROJECT_PATH/venv"
elif [ -d "$PROJECT_PATH/../venv" ]; then
    VENV_PATH="$PROJECT_PATH/../venv"
elif [ -d "/www/server/pyproject/venv/headhunter*" ]; then
    VENV_PATH=$(ls -d /www/server/pyproject/venv/headhunter* | head -1)
fi

if [ -z "$VENV_PATH" ]; then
    log_error "未找到虚拟环境，请手动激活虚拟环境后安装依赖"
    log_info "手动执行: pip install -r requirements.txt"
    read -p "依赖是否已安装? (y/N): " deps_confirm
    if [[ $deps_confirm != [yY] ]]; then
        exit 1
    fi
else
    log_info "找到虚拟环境: $VENV_PATH"
    source "$VENV_PATH/bin/activate"
    
    # 更新pip
    pip install --upgrade pip
    
    # 安装依赖
    pip install -r requirements.txt
    log_success "Python依赖更新完成"
fi

# 8. 生成加密密钥
log_info "6. 生成加密密钥..."
if [ -f "$PROJECT_PATH/generate_key.py" ]; then
    ENCRYPTION_KEY=$(python3 "$PROJECT_PATH/generate_key.py" 2>/dev/null || echo "")
    if [ -n "$ENCRYPTION_KEY" ]; then
        log_success "生成的加密密钥: $ENCRYPTION_KEY"
        log_warning "请将此密钥添加到.env文件的ENCRYPTION_KEY项中"
        
        # 自动更新.env文件
        if [ -f "$PROJECT_PATH/.env" ]; then
            if ! grep -q "ENCRYPTION_KEY" "$PROJECT_PATH/.env"; then
                echo "ENCRYPTION_KEY=$ENCRYPTION_KEY" >> "$PROJECT_PATH/.env"
                log_success "加密密钥已自动添加到.env文件"
            else
                log_warning "ENCRYPTION_KEY已存在于.env文件中，请手动检查更新"
            fi
        fi
    else
        log_error "生成加密密钥失败"
    fi
else
    log_warning "未找到generate_key.py文件"
fi

# 9. 数据库迁移
log_info "7. 执行数据库迁移..."
cd "$PROJECT_PATH"

# 创建迁移文件
python3 manage.py makemigrations
log_success "迁移文件创建完成"

# 显示迁移计划
log_info "迁移计划:"
python3 manage.py showmigrations --plan

# 确认执行迁移
read -p "是否执行数据库迁移? (y/N): " migrate_confirm
if [[ $migrate_confirm == [yY] ]]; then
    python3 manage.py migrate
    log_success "数据库迁移完成"
else
    log_warning "跳过数据库迁移，请稍后手动执行"
fi

# 10. 收集静态文件
log_info "8. 收集静态文件..."
python3 manage.py collectstatic --noinput
log_success "静态文件收集完成"

# 11. 升级完成提示
log_success "升级脚本执行完成！"
echo ""
log_info "接下来请手动完成以下步骤:"
echo "1. 通过堡塔面板重启Python项目"
echo "2. 重启Nginx服务"
echo "3. 访问网站验证功能是否正常"
echo "4. 测试新功能（SMTP状态检查、AI容错机制、批处理功能）"
echo ""
log_info "备份文件位置: $BACKUP_DIR"
log_info "如有问题，请参考UPGRADE_DEPLOYMENT_GUIDE.md文档"

# 12. 创建升级报告
REPORT_FILE="$BACKUP_DIR/upgrade_report.txt"
cat > "$REPORT_FILE" << EOF
智能猎头招聘管理系统升级报告
================================

升级时间: $(date)
项目路径: $PROJECT_PATH
备份目录: $BACKUP_DIR
Python版本: $PYTHON_VERSION
磁盘使用率: ${DISK_USAGE}%
内存使用率: ${MEMORY_USAGE}%

升级步骤完成情况:
- [✓] 系统检查
- [✓] 代码备份
- [✓] 配置备份
- [✓] 代码更新
- [✓] 权限设置
- [✓] 依赖更新
- [✓] 密钥生成
- [✓] 数据库迁移
- [✓] 静态文件收集

待手动完成:
- [ ] 重启Python项目
- [ ] 重启Nginx
- [ ] 功能验证
- [ ] 性能测试

备注:
如遇问题，可使用备份文件快速回滚
EOF

log_success "升级报告已生成: $REPORT_FILE"