#!/bin/bash

# 智能猎头招聘管理系统 - 升级前环境检查脚本
# 使用方法: bash pre_upgrade_check.sh [project_path]
# 示例: bash pre_upgrade_check.sh /www/wwwroot/headhunter

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

print_header() {
    echo "=================================="
    echo "智能猎头招聘管理系统升级前检查"
    echo "=================================="
    echo ""
}

print_separator() {
    echo ""
    echo "----------------------------------"
    echo ""
}

# 检查结果统计
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

add_check_result() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    case $1 in
        "pass") PASSED_CHECKS=$((PASSED_CHECKS + 1));;
        "fail") FAILED_CHECKS=$((FAILED_CHECKS + 1));;
        "warning") WARNING_CHECKS=$((WARNING_CHECKS + 1));;
    esac
}

# 参数处理
PROJECT_PATH=${1:-"/www/wwwroot/headhunter"}

print_header

log_info "项目路径: $PROJECT_PATH"
log_info "检查时间: $(date)"

print_separator

# 1. 系统基础环境检查
log_info "1. 系统基础环境检查"

# 检查操作系统
OS_INFO=$(cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2)
log_info "操作系统: $OS_INFO"

# 检查系统架构
ARCH=$(uname -m)
log_info "系统架构: $ARCH"

# 检查Python版本
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
    PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
    PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)
    
    if [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -ge 8 ]; then
        log_success "Python版本: $PYTHON_VERSION (满足要求 >= 3.8)"
        add_check_result "pass"
    else
        log_error "Python版本: $PYTHON_VERSION (不满足要求，需要 >= 3.8)"
        add_check_result "fail"
    fi
else
    log_error "未找到Python3"
    add_check_result "fail"
fi

# 检查pip
if command -v pip3 &> /dev/null || command -v pip &> /dev/null; then
    PIP_VERSION=$(pip3 --version 2>/dev/null || pip --version 2>/dev/null | head -1)
    log_success "pip版本: $PIP_VERSION"
    add_check_result "pass"
else
    log_error "未找到pip"
    add_check_result "fail"
fi

# 检查Git
if command -v git &> /dev/null; then
    GIT_VERSION=$(git --version)
    log_success "$GIT_VERSION"
    add_check_result "pass"
else
    log_warning "未找到Git，将需要手动更新代码"
    add_check_result "warning"
fi

print_separator

# 2. 项目目录检查
log_info "2. 项目目录检查"

if [ -d "$PROJECT_PATH" ]; then
    log_success "项目目录存在: $PROJECT_PATH"
    add_check_result "pass"
    
    # 检查关键文件
    critical_files=("manage.py" "requirements.txt" ".env" "headhunter_django/settings.py")
    for file in "${critical_files[@]}"; do
        if [ -f "$PROJECT_PATH/$file" ]; then
            log_success "关键文件存在: $file"
            add_check_result "pass"
        else
            log_error "关键文件缺失: $file"
            add_check_result "fail"
        fi
    done
    
    # 检查项目结构
    key_dirs=("jobs" "headhunter_django" "static")
    for dir in "${key_dirs[@]}"; do
        if [ -d "$PROJECT_PATH/$dir" ]; then
            log_success "关键目录存在: $dir"
            add_check_result "pass"
        else
            log_error "关键目录缺失: $dir"
            add_check_result "fail"
        fi
    done
    
else
    log_error "项目目录不存在: $PROJECT_PATH"
    add_check_result "fail"
    log_error "请检查项目路径是否正确"
    exit 1
fi

print_separator

# 3. 系统资源检查
log_info "3. 系统资源检查"

# 检查磁盘空间
DISK_USAGE=$(df -h $PROJECT_PATH | awk 'NR==2 {print $5}' | sed 's/%//')
DISK_AVAILABLE=$(df -h $PROJECT_PATH | awk 'NR==2 {print $4}')

if [ "$DISK_USAGE" -lt 80 ]; then
    log_success "磁盘使用率: ${DISK_USAGE}% (可用: $DISK_AVAILABLE)"
    add_check_result "pass"
elif [ "$DISK_USAGE" -lt 90 ]; then
    log_warning "磁盘使用率: ${DISK_USAGE}% (可用: $DISK_AVAILABLE) - 建议清理磁盘"
    add_check_result "warning"
else
    log_error "磁盘使用率: ${DISK_USAGE}% (可用: $DISK_AVAILABLE) - 磁盘空间不足"
    add_check_result "fail"
fi

# 检查内存
MEMORY_TOTAL=$(free -m | awk 'NR==2{printf "%d", $2}')
MEMORY_USED=$(free -m | awk 'NR==2{printf "%d", $3}')
MEMORY_USAGE=$(free -m | awk 'NR==2{printf "%.1f", $3/$2*100}')

if (( $(echo "$MEMORY_USAGE < 80" | bc -l) )); then
    log_success "内存使用率: ${MEMORY_USAGE}% (${MEMORY_USED}MB/${MEMORY_TOTAL}MB)"
    add_check_result "pass"
elif (( $(echo "$MEMORY_USAGE < 90" | bc -l) )); then
    log_warning "内存使用率: ${MEMORY_USAGE}% (${MEMORY_USED}MB/${MEMORY_TOTAL}MB) - 内存使用较高"
    add_check_result "warning"
else
    log_error "内存使用率: ${MEMORY_USAGE}% (${MEMORY_USED}MB/${MEMORY_TOTAL}MB) - 内存不足"
    add_check_result "fail"
fi

# 检查负载平均值
LOAD_AVERAGE=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
log_info "系统负载: $LOAD_AVERAGE"

print_separator

# 4. 虚拟环境检查
log_info "4. Python虚拟环境检查"

cd "$PROJECT_PATH"

# 查找虚拟环境
VENV_PATHS=("venv" "../venv" "/www/server/pyproject/venv/headhunter*")
VENV_FOUND=false

for venv_pattern in "${VENV_PATHS[@]}"; do
    if ls -d $venv_pattern 2>/dev/null; then
        VENV_PATH=$(ls -d $venv_pattern 2>/dev/null | head -1)
        if [ -f "$VENV_PATH/bin/activate" ]; then
            log_success "找到虚拟环境: $VENV_PATH"
            VENV_FOUND=true
            add_check_result "pass"
            
            # 检查虚拟环境中的Python版本
            VENV_PYTHON_VERSION=$($VENV_PATH/bin/python --version 2>&1 | awk '{print $2}')
            log_info "虚拟环境Python版本: $VENV_PYTHON_VERSION"
            break
        fi
    fi
done

if [ "$VENV_FOUND" = false ]; then
    log_warning "未找到Python虚拟环境，建议创建虚拟环境"
    add_check_result "warning"
fi

print_separator

# 5. 当前依赖检查
log_info "5. 当前依赖包检查"

if [ -f "$PROJECT_PATH/requirements.txt" ]; then
    log_info "检查当前已安装的依赖包..."
    
    # 关键依赖包列表
    key_packages=("django" "PyMySQL" "openai" "pandas" "openpyxl")
    
    for package in "${key_packages[@]}"; do
        if $VENV_PATH/bin/pip show "$package" &>/dev/null || pip3 show "$package" &>/dev/null; then
            if [ "$VENV_FOUND" = true ]; then
                VERSION=$($VENV_PATH/bin/pip show "$package" | grep Version | awk '{print $2}')
            else
                VERSION=$(pip3 show "$package" | grep Version | awk '{print $2}')
            fi
            log_success "$package: $VERSION"
            add_check_result "pass"
        else
            log_warning "$package: 未安装"
            add_check_result "warning"
        fi
    done
else
    log_error "requirements.txt文件不存在"
    add_check_result "fail"
fi

print_separator

# 6. 数据库连接检查
log_info "6. 数据库连接检查"

if [ -f "$PROJECT_PATH/.env" ]; then
    # 从.env文件读取数据库配置
    DB_HOST=$(grep "DB_HOST" "$PROJECT_PATH/.env" | cut -d'=' -f2)
    DB_PORT=$(grep "DB_PORT" "$PROJECT_PATH/.env" | cut -d'=' -f2 | head -1)
    DB_NAME=$(grep "DB_NAME" "$PROJECT_PATH/.env" | cut -d'=' -f2)
    DB_USER=$(grep "DB_USER" "$PROJECT_PATH/.env" | cut -d'=' -f2)
    
    log_info "数据库配置:"
    log_info "  主机: $DB_HOST"
    log_info "  端口: ${DB_PORT:-3306}"
    log_info "  数据库: $DB_NAME"
    log_info "  用户: $DB_USER"
    
    # 简单的连接测试（需要mysql客户端）
    if command -v mysql &> /dev/null; then
        DB_PASSWORD=$(grep "DB_PASSWORD" "$PROJECT_PATH/.env" | cut -d'=' -f2)
        if timeout 10 mysql -h"$DB_HOST" -P"${DB_PORT:-3306}" -u"$DB_USER" -p"$DB_PASSWORD" -e "SELECT 1;" &>/dev/null; then
            log_success "数据库连接测试通过"
            add_check_result "pass"
        else
            log_error "数据库连接测试失败"
            add_check_result "fail"
        fi
    else
        log_warning "未找到mysql客户端，无法测试数据库连接"
        add_check_result "warning"
    fi
else
    log_error "未找到.env配置文件"
    add_check_result "fail"
fi

print_separator

# 7. Web服务器检查
log_info "7. Web服务器检查"

# 检查Nginx
if systemctl is-active --quiet nginx 2>/dev/null; then
    NGINX_VERSION=$(nginx -v 2>&1 | awk '{print $3}')
    log_success "Nginx运行中: $NGINX_VERSION"
    add_check_result "pass"
elif command -v nginx &> /dev/null; then
    log_warning "Nginx已安装但未运行"
    add_check_result "warning"
else
    log_error "未找到Nginx"
    add_check_result "fail"
fi

# 检查端口使用情况
COMMON_PORTS=("80" "443" "8000")
for port in "${COMMON_PORTS[@]}"; do
    if netstat -tlnp 2>/dev/null | grep ":$port " >/dev/null; then
        log_success "端口 $port 正在监听"
        add_check_result "pass"
    else
        log_warning "端口 $port 未监听"
        add_check_result "warning"
    fi
done

print_separator

# 8. 新功能依赖检查
log_info "8. 新功能依赖检查"

# 检查新增依赖包
new_packages=("APScheduler" "pytz" "cryptography")
for package in "${new_packages[@]}"; do
    if $VENV_PATH/bin/pip show "$package" &>/dev/null || pip3 show "$package" &>/dev/null; then
        if [ "$VENV_FOUND" = true ]; then
            VERSION=$($VENV_PATH/bin/pip show "$package" | grep Version | awk '{print $2}')
        else
            VERSION=$(pip3 show "$package" | grep Version | awk '{print $2}')
        fi
        log_success "新功能依赖 $package: $VERSION (已安装)"
        add_check_result "pass"
    else
        log_warning "新功能依赖 $package: 未安装 (升级时将自动安装)"
        add_check_result "warning"
    fi
done

print_separator

# 9. 备份空间检查
log_info "9. 备份空间检查"

PROJECT_SIZE=$(du -sh "$PROJECT_PATH" | awk '{print $1}')
log_info "项目大小: $PROJECT_SIZE"

BACKUP_DIR="/www/backup"
if [ -d "$BACKUP_DIR" ]; then
    BACKUP_AVAILABLE=$(df -h "$BACKUP_DIR" | awk 'NR==2 {print $4}')
    log_success "备份目录可用空间: $BACKUP_AVAILABLE"
    add_check_result "pass"
else
    log_warning "备份目录不存在，将在升级时创建"
    add_check_result "warning"
fi

print_separator

# 10. 堡塔面板检查
log_info "10. 堡塔面板检查"

if command -v bt &> /dev/null; then
    BT_VERSION=$(bt version 2>/dev/null || echo "未知版本")
    log_success "堡塔面板已安装: $BT_VERSION"
    add_check_result "pass"
    
    # 检查面板服务状态
    if systemctl is-active --quiet bt 2>/dev/null; then
        log_success "堡塔面板服务运行中"
        add_check_result "pass"
    else
        log_warning "堡塔面板服务未运行"
        add_check_result "warning"
    fi
else
    log_error "未找到堡塔面板"
    add_check_result "fail"
fi

print_separator

# 生成检查报告
log_info "检查完成，生成报告..."

REPORT_FILE="/tmp/pre_upgrade_check_$(date +%Y%m%d_%H%M%S).txt"
cat > "$REPORT_FILE" << EOF
智能猎头招聘管理系统升级前检查报告
=====================================

检查时间: $(date)
项目路径: $PROJECT_PATH
系统信息: $OS_INFO ($ARCH)

检查结果统计:
- 总检查项: $TOTAL_CHECKS
- 通过: $PASSED_CHECKS
- 警告: $WARNING_CHECKS  
- 失败: $FAILED_CHECKS

系统环境:
- Python版本: $PYTHON_VERSION
- 项目大小: $PROJECT_SIZE
- 磁盘使用率: ${DISK_USAGE}%
- 内存使用率: ${MEMORY_USAGE}%

建议:
EOF

# 根据检查结果给出建议
if [ $FAILED_CHECKS -gt 0 ]; then
    echo "- 有 $FAILED_CHECKS 项检查失败，建议修复后再进行升级" >> "$REPORT_FILE"
    echo "- 请参考检查日志解决问题" >> "$REPORT_FILE"
fi

if [ $WARNING_CHECKS -gt 0 ]; then
    echo "- 有 $WARNING_CHECKS 项检查警告，建议在升级前处理" >> "$REPORT_FILE"
fi

if [ $FAILED_CHECKS -eq 0 ] && [ $WARNING_CHECKS -le 2 ]; then
    echo "- 系统环境良好，可以进行升级" >> "$REPORT_FILE"
fi

echo "" >> "$REPORT_FILE"
echo "详细日志请参考命令行输出" >> "$REPORT_FILE"

# 输出最终结果
print_separator
echo "检查结果汇总:"
echo "=============="
echo "总检查项: $TOTAL_CHECKS"
echo "✓ 通过: $PASSED_CHECKS"
echo "! 警告: $WARNING_CHECKS"
echo "✗ 失败: $FAILED_CHECKS"
echo ""

if [ $FAILED_CHECKS -eq 0 ]; then
    if [ $WARNING_CHECKS -eq 0 ]; then
        log_success "所有检查项通过，系统环境良好，可以安全进行升级！"
    else
        log_warning "主要检查项通过，但有 $WARNING_CHECKS 项警告，建议处理后升级"
    fi
else
    log_error "有 $FAILED_CHECKS 项检查失败，请修复问题后再进行升级"
    echo ""
    echo "常见问题解决方案:"
    echo "- Python版本过低: 升级Python到3.8+"
    echo "- 磁盘空间不足: 清理磁盘空间"
    echo "- 数据库连接失败: 检查数据库配置和网络连接"
    echo "- 关键文件缺失: 检查项目完整性"
fi

echo ""
log_info "检查报告已保存到: $REPORT_FILE"
echo ""
echo "如果检查通过，可以执行升级脚本："
echo "bash upgrade_script.sh $PROJECT_PATH"