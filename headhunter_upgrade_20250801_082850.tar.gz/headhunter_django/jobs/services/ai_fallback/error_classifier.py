"""
AI Error Classifier

Classifies AI model errors and determines retry/fallback strategies.
"""

import logging
from enum import Enum
from typing import Dict, Any, Optional, Set
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class ErrorType(Enum):
    """Classification of AI model errors."""
    # Retryable errors (transient)
    TIMEOUT = "timeout"
    RATE_LIMIT = "rate_limit"
    SERVER_ERROR = "server_error"
    NETWORK_ERROR = "network_error"
    TEMPORARY_UNAVAILABLE = "temporary_unavailable"
    
    # Non-retryable errors (permanent)
    AUTH_ERROR = "auth_error"
    QUOTA_EXCEEDED = "quota_exceeded"
    MODEL_NOT_FOUND = "model_not_found"
    CONTENT_FILTERED = "content_filtered"
    CONTEXT_TOO_LONG = "context_too_long"
    INVALID_REQUEST = "invalid_request"
    
    # Unknown errors
    UNKNOWN = "unknown"


@dataclass
class ErrorAnalysis:
    """Analysis result of an AI model error."""
    error_type: ErrorType
    is_retryable: bool
    is_fallback_worthy: bool
    human_message: str
    technical_details: str
    suggested_action: str
    retry_delay: Optional[int] = None  # Seconds to wait before retry


class ErrorClassifier:
    """Classifies AI model errors and suggests handling strategies."""
    
    def __init__(self):
        """Initialize the error classifier."""
        # Retryable errors that might succeed on retry
        self.retryable_errors: Set[ErrorType] = {
            ErrorType.TIMEOUT,
            ErrorType.RATE_LIMIT,
            ErrorType.SERVER_ERROR,
            ErrorType.NETWORK_ERROR,
            ErrorType.TEMPORARY_UNAVAILABLE
        }
        
        # Errors that should trigger fallback to another model
        self.fallback_worthy_errors: Set[ErrorType] = {
            ErrorType.TIMEOUT,
            ErrorType.RATE_LIMIT,
            ErrorType.SERVER_ERROR,
            ErrorType.QUOTA_EXCEEDED,
            ErrorType.MODEL_NOT_FOUND,
            ErrorType.CONTENT_FILTERED,
            ErrorType.CONTEXT_TOO_LONG,
            ErrorType.TEMPORARY_UNAVAILABLE
        }
        
        # Error patterns for classification
        self.error_patterns = self._build_error_patterns()
        
        # Human-readable error messages
        self.human_messages = self._build_human_messages()
    
    def classify_error(self, error: Exception, provider: str, model: str, context: Dict[str, Any] = None) -> ErrorAnalysis:
        """
        Classify an AI model error and provide handling recommendations.
        
        Args:
            error: The exception that occurred
            provider: The AI provider (e.g., 'qwen', 'kimi')
            model: The model name
            context: Additional context about the request
            
        Returns:
            ErrorAnalysis with classification and recommendations
        """
        context = context or {}
        error_str = str(error).lower()
        error_type = self._detect_error_type(error, error_str, provider)
        
        # Determine handling strategy
        is_retryable = error_type in self.retryable_errors
        is_fallback_worthy = error_type in self.fallback_worthy_errors
        
        # Generate human-readable message
        human_message = self._generate_human_message(error_type, provider, model, context)
        
        # Get technical details
        technical_details = f"{type(error).__name__}: {str(error)}"
        
        # Suggest action
        suggested_action = self._suggest_action(error_type, is_retryable, is_fallback_worthy)
        
        # Calculate retry delay
        retry_delay = self._calculate_retry_delay(error_type, context.get('attempt', 1))
        
        return ErrorAnalysis(
            error_type=error_type,
            is_retryable=is_retryable,
            is_fallback_worthy=is_fallback_worthy,
            human_message=human_message,
            technical_details=technical_details,
            suggested_action=suggested_action,
            retry_delay=retry_delay
        )
    
    def _detect_error_type(self, error: Exception, error_str: str, provider: str) -> ErrorType:
        """Detect the type of error based on the exception and error message."""
        # Check for specific exception types first
        error_class = type(error).__name__.lower()
        
        # Import openai to check for specific error types
        try:
            import openai
            if isinstance(error, openai.APITimeoutError):
                return ErrorType.TIMEOUT
            elif isinstance(error, openai.RateLimitError):
                return ErrorType.RATE_LIMIT
            elif isinstance(error, openai.AuthenticationError):
                return ErrorType.AUTH_ERROR
            elif isinstance(error, openai.NotFoundError):
                return ErrorType.MODEL_NOT_FOUND
        except ImportError:
            pass
        
        # Pattern-based detection
        for patterns, error_type in self.error_patterns.items():
            if any(pattern in error_str for pattern in patterns):
                return error_type
        
        # Provider-specific error detection
        provider_error_type = self._detect_provider_specific_error(error_str, provider)
        if provider_error_type:
            return provider_error_type
        
        # Check for common error indicators
        if 'timeout' in error_str or 'timed out' in error_str:
            return ErrorType.TIMEOUT
        elif 'rate limit' in error_str or 'too many requests' in error_str:
            return ErrorType.RATE_LIMIT
        elif 'unauthorized' in error_str or 'invalid api key' in error_str:
            return ErrorType.AUTH_ERROR
        elif 'quota' in error_str or 'balance' in error_str:
            return ErrorType.QUOTA_EXCEEDED
        elif 'context' in error_str and ('too long' in error_str or 'limit' in error_str):
            return ErrorType.CONTEXT_TOO_LONG
        elif 'content' in error_str and ('filter' in error_str or 'policy' in error_str):
            return ErrorType.CONTENT_FILTERED
        elif any(keyword in error_str for keyword in ['500', 'internal server', 'server error']):
            return ErrorType.SERVER_ERROR
        elif any(keyword in error_str for keyword in ['network', 'connection', 'dns']):
            return ErrorType.NETWORK_ERROR
        
        return ErrorType.UNKNOWN
    
    def _detect_provider_specific_error(self, error_str: str, provider: str) -> Optional[ErrorType]:
        """Detect provider-specific error patterns."""
        provider_patterns = {
            'qwen': {
                'invalid_api_key': ErrorType.AUTH_ERROR,
                'insufficient_quota': ErrorType.QUOTA_EXCEEDED,
                'model_not_found': ErrorType.MODEL_NOT_FOUND,
                'request_too_large': ErrorType.CONTEXT_TOO_LONG,
            },
            'kimi': {
                'invalid_api_key': ErrorType.AUTH_ERROR,
                'context_length_exceeded': ErrorType.CONTEXT_TOO_LONG,
                'billing': ErrorType.QUOTA_EXCEEDED,
            },
            'doubao': {
                'invalid_authentication': ErrorType.AUTH_ERROR,
                'model_overload': ErrorType.SERVER_ERROR,
                'content_filter': ErrorType.CONTENT_FILTERED,
            },
            'hunyuan': {
                'signature': ErrorType.AUTH_ERROR,
                'qps_limit': ErrorType.RATE_LIMIT,
                'text_moderation': ErrorType.CONTENT_FILTERED,
            },
            'chatglm': {
                'invalid_api_key': ErrorType.AUTH_ERROR,
                'model_not_exist': ErrorType.MODEL_NOT_FOUND,
                'context_too_long': ErrorType.CONTEXT_TOO_LONG,
            },
            'deepseek': {
                'invalid_api_key': ErrorType.AUTH_ERROR,
                'insufficient_balance': ErrorType.QUOTA_EXCEEDED,
                'context_limit_exceeded': ErrorType.CONTEXT_TOO_LONG,
            },
            'minimax': {
                'invalid_api_key': ErrorType.AUTH_ERROR,
                'balance_insufficient': ErrorType.QUOTA_EXCEEDED,
                'content_filtered': ErrorType.CONTENT_FILTERED,
                'model_overloaded': ErrorType.SERVER_ERROR,
            }
        }
        
        if provider in provider_patterns:
            for pattern, error_type in provider_patterns[provider].items():
                if pattern in error_str:
                    return error_type
        
        return None
    
    def _build_error_patterns(self) -> Dict[tuple, ErrorType]:
        """Build error pattern mappings."""
        return {
            # Timeout patterns
            ('timeout', 'timed out', 'deadline exceeded'): ErrorType.TIMEOUT,
            
            # Rate limiting patterns
            ('rate limit', 'too many requests', '429', 'qps'): ErrorType.RATE_LIMIT,
            
            # Authentication patterns
            ('unauthorized', 'invalid api key', 'authentication failed', '401'): ErrorType.AUTH_ERROR,
            
            # Quota patterns
            ('quota exceeded', 'insufficient quota', 'balance insufficient', 'credit limit'): ErrorType.QUOTA_EXCEEDED,
            
            # Server error patterns
            ('internal server error', '500', '502', '503', 'server unavailable'): ErrorType.SERVER_ERROR,
            
            # Network error patterns
            ('connection error', 'network error', 'dns resolution', 'connection refused'): ErrorType.NETWORK_ERROR,
            
            # Context length patterns
            ('context length', 'token limit', 'request too large', 'context_length_exceeded'): ErrorType.CONTEXT_TOO_LONG,
            
            # Content filtering patterns
            ('content filter', 'content policy', 'safety filter', 'moderation'): ErrorType.CONTENT_FILTERED,
            
            # Model not found patterns
            ('model not found', 'model not exist', 'invalid model', '404'): ErrorType.MODEL_NOT_FOUND,
        }
    
    def _build_human_messages(self) -> Dict[ErrorType, str]:
        """Build human-readable error message templates."""
        return {
            ErrorType.TIMEOUT: "{provider} 响应超时",
            ErrorType.RATE_LIMIT: "{provider} 请求频率超限",
            ErrorType.SERVER_ERROR: "{provider} 服务器繁忙",
            ErrorType.NETWORK_ERROR: "{provider} 网络连接失败",
            ErrorType.TEMPORARY_UNAVAILABLE: "{provider} 暂时不可用",
            ErrorType.AUTH_ERROR: "{provider} API密钥无效",
            ErrorType.QUOTA_EXCEEDED: "{provider} 配额不足",
            ErrorType.MODEL_NOT_FOUND: "{provider} 模型不存在",
            ErrorType.CONTENT_FILTERED: "{provider} 内容被过滤",
            ErrorType.CONTEXT_TOO_LONG: "{provider} 请求内容过长",
            ErrorType.INVALID_REQUEST: "{provider} 请求格式错误",
            ErrorType.UNKNOWN: "{provider} 未知错误",
        }
    
    def _generate_human_message(self, error_type: ErrorType, provider: str, model: str, context: Dict[str, Any]) -> str:
        """Generate a human-readable error message."""
        base_message = self.human_messages.get(error_type, "{provider} 发生错误")
        
        # Provider name mapping
        provider_names = {
            'qwen': '通义千问',
            'kimi': 'Kimi',
            'doubao': '豆包',
            'hunyuan': '混元',
            'chatglm': 'ChatGLM',
            'deepseek': '深度求索',
            'minimax': 'MiniMax',
            'together': 'Together AI'
        }
        
        provider_display = provider_names.get(provider.lower(), provider.upper())
        message = base_message.format(provider=provider_display)
        
        # Add specific details based on error type
        if error_type == ErrorType.CONTEXT_TOO_LONG:
            tokens = context.get('token_count')
            if tokens:
                message += f"（输入 {tokens} tokens）"
        elif error_type == ErrorType.RATE_LIMIT:
            message += "，请稍后重试"
        elif error_type == ErrorType.QUOTA_EXCEEDED:
            message += "，请检查账户余额"
        
        return message
    
    def _suggest_action(self, error_type: ErrorType, is_retryable: bool, is_fallback_worthy: bool) -> str:
        """Suggest the appropriate action for handling the error."""
        if error_type == ErrorType.AUTH_ERROR:
            return "检查API密钥配置"
        elif error_type == ErrorType.QUOTA_EXCEEDED:
            return "充值账户或更换模型"
        elif error_type == ErrorType.CONTEXT_TOO_LONG:
            return "减少输入内容或使用长上下文模型"
        elif error_type == ErrorType.CONTENT_FILTERED:
            return "修改输入内容或更换模型"
        elif error_type == ErrorType.MODEL_NOT_FOUND:
            return "更换可用模型"
        elif is_retryable:
            return "稍后重试"
        elif is_fallback_worthy:
            return "切换到备用模型"
        else:
            return "检查请求参数"
    
    def _calculate_retry_delay(self, error_type: ErrorType, attempt: int) -> Optional[int]:
        """Calculate the delay before retrying based on error type and attempt number."""
        if error_type == ErrorType.RATE_LIMIT:
            # Exponential backoff for rate limits: 1s, 2s, 4s, 8s...
            return min(2 ** (attempt - 1), 30)
        elif error_type == ErrorType.SERVER_ERROR:
            # Fixed delay for server errors: 2s, 4s, 6s...
            return min(2 * attempt, 10)
        elif error_type == ErrorType.TIMEOUT:
            # Shorter delay for timeouts: 1s, 2s, 3s...
            return min(attempt, 5)
        elif error_type == ErrorType.NETWORK_ERROR:
            # Progressive delay for network issues: 3s, 6s, 9s...
            return min(3 * attempt, 15)
        
        return None  # No delay for non-retryable errors