"""
AI Fallback Manager

Manages automatic fallback between AI models when primary models fail.
"""

import time
import logging
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Callable
from django.contrib.auth.models import User

from .retry_strategy import RetryStrategy, RetryResult
from .error_classifier import ErrorClassifier

logger = logging.getLogger(__name__)


@dataclass
class ModelAttempt:
    """Information about an attempt to use a specific model."""
    model_id: str
    provider: str
    model_name: str
    start_time: float
    end_time: Optional[float] = None
    success: bool = False
    error_message: Optional[str] = None
    retry_count: int = 0
    retry_history: List = field(default_factory=list)


@dataclass
class FallbackResult:
    """Result of a fallback operation."""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    
    # Execution details
    final_model: Optional[str] = None
    attempts: List[ModelAttempt] = field(default_factory=list)
    total_time: float = 0
    
    # Metrics
    models_tried: int = 0
    total_retries: int = 0
    fallback_count: int = 0
    
    # Messages
    human_readable_log: List[str] = field(default_factory=list)


class FallbackManager:
    """Manages automatic fallback between AI models."""
    
    def __init__(self, retry_strategy: Optional[RetryStrategy] = None):
        """
        Initialize the fallback manager.
        
        Args:
            retry_strategy: Strategy for retrying failed requests
        """
        self.retry_strategy = retry_strategy or RetryStrategy()
        self.error_classifier = ErrorClassifier()
    
    def execute_with_fallback(self, user: User, primary_model: str, fallback_models: List[str],
                             request_func: Callable[[str], Dict[str, Any]], 
                             context: Dict[str, Any] = None) -> FallbackResult:
        """
        Execute an AI request with automatic fallback.
        
        Args:
            user: The user making the request
            primary_model: Primary model to try first
            fallback_models: List of fallback models to try if primary fails
            request_func: Function to call with model_id, should return dict with 'success' key
            context: Additional context for error handling
            
        Returns:
            FallbackResult with execution details and final result
        """
        context = context or {}
        start_time = time.time()
        result = FallbackResult()
        
        # Build complete model list (primary + fallbacks)
        all_models = [primary_model] + [m for m in fallback_models if m != primary_model]
        
        # Get model information for better error messages
        model_info = self._get_model_info(all_models)
        
        logger.info(f"Starting AI request for user {user.username} with model chain: {all_models}")
        result.human_readable_log.append(f"尝试使用 {self._get_model_display_name(primary_model, model_info)} 处理请求...")
        
        for i, model_id in enumerate(all_models):
            model_start_time = time.time()
            model_attempt = ModelAttempt(
                model_id=model_id,
                provider=model_info.get(model_id, {}).get('provider', 'unknown'),
                model_name=model_info.get(model_id, {}).get('name', model_id),
                start_time=model_start_time
            )
            
            try:
                # Check if user has access to this model
                access_check = self._check_model_access(user, model_id)
                if not access_check.get('has_access'):
                    error_msg = f"无权访问模型 {model_id}: {access_check.get('message', '未知原因')}"
                    logger.warning(error_msg)
                    result.human_readable_log.append(f"❌ {self._get_model_display_name(model_id, model_info)} 无法访问，跳过")
                    
                    model_attempt.end_time = time.time()
                    model_attempt.error_message = error_msg
                    result.attempts.append(model_attempt)
                    continue
                
                # Create request function wrapper for this specific model
                def model_request():
                    return request_func(model_id)
                
                # Execute with retry strategy
                model_result = self.retry_strategy.execute_with_retry(
                    model_request, 
                    model_id, 
                    model_attempt.provider,
                    context
                )
                
                # Update attempt information
                model_attempt.end_time = time.time()
                model_attempt.retry_count = model_result.get('attempt', 1) - 1
                model_attempt.retry_history = model_result.get('retry_history', [])
                result.total_retries += model_attempt.retry_count
                
                if model_result.get('success'):
                    # Success!
                    model_attempt.success = True
                    result.success = True
                    result.data = model_result.get('data')
                    result.final_model = model_id
                    
                    success_msg = f"✅ {self._get_model_display_name(model_id, model_info)} 成功处理请求"
                    if model_attempt.retry_count > 0:
                        success_msg += f"（重试 {model_attempt.retry_count} 次后成功）"
                    
                    logger.info(success_msg)
                    result.human_readable_log.append(success_msg)
                    break
                else:
                    # Model failed
                    model_attempt.error_message = model_result.get('message', '未知错误')
                    
                    if i < len(all_models) - 1:  # Not the last model
                        next_model = all_models[i + 1]
                        next_model_name = self._get_model_display_name(next_model, model_info)
                        
                        if model_result.get('should_fallback', True):
                            fallback_msg = f"❌ {self._get_model_display_name(model_id, model_info)} 失败: {model_result.get('message', '未知错误')}。正在尝试 {next_model_name}..."
                            logger.warning(fallback_msg)
                            result.human_readable_log.append(fallback_msg)
                            result.fallback_count += 1
                        else:
                            # Error is not fallback-worthy, abort
                            error_msg = f"❌ {self._get_model_display_name(model_id, model_info)} 发生无法恢复的错误: {model_result.get('message', '未知错误')}"
                            logger.error(error_msg)
                            result.human_readable_log.append(error_msg)
                            result.error = model_result.get('message', '无法恢复的错误')
                            break
                    else:
                        # Last model failed
                        error_msg = f"❌ {self._get_model_display_name(model_id, model_info)} 失败: {model_result.get('message', '未知错误')}。所有模型均已尝试"
                        logger.error(error_msg)
                        result.human_readable_log.append(error_msg)
                        result.error = "所有备用模型均失败"
            
            except Exception as unexpected_error:
                # Unexpected error not caught by retry strategy
                model_attempt.end_time = time.time()
                model_attempt.error_message = str(unexpected_error)
                
                error_msg = f"❌ {self._get_model_display_name(model_id, model_info)} 发生意外错误: {str(unexpected_error)}"
                logger.exception(error_msg)
                result.human_readable_log.append(error_msg)
                
                if i == len(all_models) - 1:  # Last model
                    result.error = f"意外错误: {str(unexpected_error)}"
            
            finally:
                result.attempts.append(model_attempt)
                result.models_tried += 1
        
        # Finalize result
        result.total_time = time.time() - start_time
        
        if result.success:
            logger.info(f"AI request completed successfully with {result.final_model} after {result.models_tried} models and {result.total_retries} retries in {result.total_time:.2f}s")
        else:
            logger.error(f"AI request failed after trying {result.models_tried} models with {result.total_retries} total retries in {result.total_time:.2f}s")
            result.human_readable_log.append(f"所有 {result.models_tried} 个模型均失败，请检查网络连接和API密钥配置")
        
        return result
    
    def _get_model_info(self, model_ids: List[str]) -> Dict[str, Dict[str, Any]]:
        """Get model information for display purposes."""
        try:
            from ..ai_config import model_registry
            model_registry.ensure_loaded()
            
            model_info = {}
            for model_id in model_ids:
                config = model_registry.get_model(model_id)
                if config:
                    model_info[model_id] = {
                        'name': config.name,
                        'provider': config.provider
                    }
                else:
                    # Fallback to settings
                    from django.conf import settings
                    legacy_config = getattr(settings, 'AI_MODELS', {}).get(model_id, {})
                    model_info[model_id] = {
                        'name': legacy_config.get('name', model_id),
                        'provider': legacy_config.get('provider', 'unknown')
                    }
            
            return model_info
        except Exception as e:
            logger.warning(f"Could not get model info: {e}")
            return {}
    
    def _get_model_display_name(self, model_id: str, model_info: Dict[str, Dict[str, Any]]) -> str:
        """Get a human-readable display name for a model."""
        info = model_info.get(model_id, {})
        name = info.get('name', model_id)
        
        # Shorten long names for better readability
        if len(name) > 20:
            provider = info.get('provider', '').upper()
            if provider:
                return f"{provider}-{model_id.split('_')[-1]}"
        
        return name
    
    def _check_model_access(self, user: User, model_id: str) -> Dict[str, Any]:
        """Check if user has access to a specific model."""
        try:
            from ..ai_manager import ai_manager
            return ai_manager.check_user_access(user, model_id)
        except Exception as e:
            logger.warning(f"Could not check model access for {model_id}: {e}")
            return {'has_access': True}  # Default to allowing access
    
    def get_fallback_summary(self, result: FallbackResult) -> str:
        """Get a concise summary of the fallback operation."""
        if result.success:
            summary = f"成功使用 {result.final_model}"
            if result.fallback_count > 0:
                summary += f"（经过 {result.fallback_count} 次模型切换）"
            if result.total_retries > 0:
                summary += f"（总计重试 {result.total_retries} 次）"
            return summary
        else:
            return f"所有 {result.models_tried} 个模型均失败: {result.error}"
    
    def get_performance_metrics(self, result: FallbackResult) -> Dict[str, Any]:
        """Get performance metrics from the fallback operation."""
        return {
            'total_time': result.total_time,
            'models_tried': result.models_tried,
            'fallback_count': result.fallback_count,
            'total_retries': result.total_retries,
            'success_rate': 1.0 if result.success else 0.0,
            'average_time_per_model': result.total_time / result.models_tried if result.models_tried > 0 else 0,
            'final_model': result.final_model
        }