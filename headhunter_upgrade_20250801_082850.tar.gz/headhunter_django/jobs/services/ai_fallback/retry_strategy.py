"""
AI Retry Strategy

Manages retry logic for AI model requests with intelligent backoff.
"""

import time
import logging
from dataclasses import dataclass
from typing import Dict, Any, Optional, Callable
from enum import Enum

from .error_classifier import ErrorClassifier, ErrorType

logger = logging.getLogger(__name__)


class RetryResult(Enum):
    """Result of a retry attempt."""
    SUCCESS = "success"
    RETRY = "retry"
    FALLBACK = "fallback"
    ABORT = "abort"


@dataclass
class RetryAttempt:
    """Information about a retry attempt."""
    attempt: int
    error_type: ErrorType
    delay: int
    message: str


class RetryStrategy:
    """Manages retry logic for AI model requests."""
    
    def __init__(self, max_retries: int = 3, max_total_time: int = 300):
        """
        Initialize the retry strategy.
        
        Args:
            max_retries: Maximum number of retry attempts per model
            max_total_time: Maximum total time to spend on retries (seconds)
        """
        self.max_retries = max_retries
        self.max_total_time = max_total_time
        self.error_classifier = ErrorClassifier()
    
    def should_retry(self, error: Exception, attempt: int, model_id: str, provider: str, 
                    start_time: float, context: Dict[str, Any] = None) -> RetryResult:
        """
        Determine if a request should be retried.
        
        Args:
            error: The exception that occurred
            attempt: Current attempt number (1-based)
            model_id: The model being used
            provider: The provider name
            start_time: When the first attempt started
            context: Additional context
            
        Returns:
            RetryResult indicating what action to take
        """
        context = context or {}
        
        # Check time limits
        elapsed_time = time.time() - start_time
        if elapsed_time > self.max_total_time:
            logger.warning(f"Max total time ({self.max_total_time}s) exceeded for {model_id}")
            return RetryResult.FALLBACK
        
        # Check attempt limits
        if attempt > self.max_retries:
            logger.warning(f"Max retries ({self.max_retries}) exceeded for {model_id}")
            return RetryResult.FALLBACK
        
        # Classify the error
        error_analysis = self.error_classifier.classify_error(error, provider, model_id, context)
        
        # Log the error
        logger.warning(f"Attempt {attempt} failed for {model_id}: {error_analysis.human_message}")
        
        # Decide based on error type
        if not error_analysis.is_retryable:
            if error_analysis.is_fallback_worthy:
                logger.info(f"Non-retryable error for {model_id}, attempting fallback")
                return RetryResult.FALLBACK
            else:
                logger.error(f"Non-retryable, non-fallback error for {model_id}, aborting")
                return RetryResult.ABORT
        
        # Apply retry delay if specified
        if error_analysis.retry_delay:
            logger.info(f"Waiting {error_analysis.retry_delay}s before retry {attempt + 1} for {model_id}")
            time.sleep(error_analysis.retry_delay)
        
        return RetryResult.RETRY
    
    def execute_with_retry(self, func: Callable, model_id: str, provider: str, 
                          context: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Execute a function with retry logic.
        
        Args:
            func: Function to execute (should return dict with 'success' key)
            model_id: The model being used
            provider: The provider name
            context: Additional context
            
        Returns:
            Result dictionary with success status and data/error
        """
        context = context or {}
        start_time = time.time()
        attempt = 1
        retry_history = []
        
        while attempt <= self.max_retries + 1:  # +1 for initial attempt
            try:
                # Execute the function
                result = func()
                
                # Check if successful
                if isinstance(result, dict) and result.get('success'):
                    if attempt > 1:
                        logger.info(f"Success on attempt {attempt} for {model_id} after {len(retry_history)} retries")
                    return {
                        'success': True,
                        'data': result.get('data'),
                        'attempt': attempt,
                        'retry_history': retry_history,
                        'total_time': time.time() - start_time
                    }
                else:
                    # Function returned failure result
                    error_msg = result.get('message', 'Unknown error') if isinstance(result, dict) else str(result)
                    raise Exception(error_msg)
                    
            except Exception as error:
                # Determine retry strategy
                retry_result = self.should_retry(error, attempt, model_id, provider, start_time, context)
                
                # Record the attempt
                error_analysis = self.error_classifier.classify_error(error, provider, model_id, context)
                retry_history.append(RetryAttempt(
                    attempt=attempt,
                    error_type=error_analysis.error_type,
                    delay=error_analysis.retry_delay or 0,
                    message=error_analysis.human_message
                ))
                
                if retry_result == RetryResult.RETRY:
                    attempt += 1
                    continue
                elif retry_result == RetryResult.FALLBACK:
                    return {
                        'success': False,
                        'error': 'retry_exhausted',
                        'message': f"{model_id} 重试失败，需要切换模型",
                        'should_fallback': True,
                        'retry_history': retry_history,
                        'total_time': time.time() - start_time,
                        'last_error': error_analysis.technical_details
                    }
                else:  # ABORT
                    return {
                        'success': False,
                        'error': 'non_retryable',
                        'message': f"{model_id} 发生无法恢复的错误",
                        'should_fallback': False,
                        'retry_history': retry_history,
                        'total_time': time.time() - start_time,
                        'last_error': error_analysis.technical_details
                    }
        
        # Should not reach here, but just in case
        return {
            'success': False,
            'error': 'max_retries_exceeded',
            'message': f"{model_id} 达到最大重试次数",
            'should_fallback': True,
            'retry_history': retry_history,
            'total_time': time.time() - start_time
        }