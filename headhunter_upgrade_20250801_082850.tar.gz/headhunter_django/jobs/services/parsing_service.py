import logging
import json
import re
import openai
import pandas as pd
import docx
from django.conf import settings
from django.contrib.auth.models import User
from ..models import ApiKey
from ..utils import decrypt_key

# 定义研究方向关键词列表 (严格限制提取范围)
RESEARCH_DIRECTION_KEYWORDS = [
    "大模型", "LLM", "ChatGPT", "Transformer", "预训练", "对齐", "指令微调", "SFT", "RLHF",
    "后训练", "Post-training", "Instruct-tuning", "Alignment",
    "多模态", "Multimodal", "图文", "语音多模态", "音视频理解",
    "强化学习", "Reinforcement Learning", "Actor-Critic", "PPO", "DQN",
    "自然语言处理", "NLP", "问答系统", "文本生成", "语言建模",
    "语音合成", "Speech Synthesis", "语音识别", "ASR", "TTS",
    "图神经网络", "GNN", "图表示学习", "Graph Learning",
    "推荐系统", "Recommendation", "大规模推荐",
    "知识图谱", "Knowledge Graph", "KG",
    "代码生成", "Code Generation", "Program Synthesis",
    "大模型安全", "模型压缩", "LoRA", "PEFT", "Prompt Engineering",
    "数据合成", "数据增强", "Synthetic Data",
    "因果推理", "Causal Inference", "AIGC", "Agent"
]

def _call_ai_model(prompt: str, provider_key: str, user: User):
    """一个通用的、私有的AI模型调用函数。"""
    model_config = settings.AI_MODELS.get(provider_key)
    if not model_config:
        return {"error": "配置错误", "message": f"模型 '{provider_key}' 的配置未在settings.py中找到。"}

    provider_for_db_lookup = model_config.get('provider')
    base_url = model_config.get('base_url')
    model_name = model_config.get('model_name')

    if not all([provider_for_db_lookup, base_url, model_name]):
        return {"error": "配置不完整", "message": f"模型 '{provider_key}' 在settings.py中的配置不完整。"}

    try:
        api_key_obj = ApiKey.objects.get(user=user, provider=provider_for_db_lookup)
        api_key = decrypt_key(api_key_obj.api_key_encrypted)
    except ApiKey.DoesNotExist:
        return {"error": "密钥缺失", "message": f"未在数据库中找到您为服务商 '{provider_for_db_lookup.upper()}' 配置的API密钥，请先在“API密钥管理”页面添加。"}

    if not api_key:
        return {"error": "密钥无效", "message": "从数据库解密后的API密钥为空。"}

    # 尝试使用新的AI适配器系统（带自动回退功能）
    try:
        from .ai_manager import ai_manager
        result = ai_manager.call_model_with_fallback(prompt, user, provider_key, json_mode=True)
        
        # 转换新格式为旧格式以保持向后兼容
        if result.get('success'):
            data = result.get('data', {})
            if isinstance(data, dict) and "jobs" in data and isinstance(data["jobs"], list):
                return data
            else:
                # 如果是其他格式的成功响应，包装为旧格式
                return data
        else:
            # 返回增强的错误信息（包含回退尝试信息）
            error_result = {
                "error": result.get("error", "未知错误"),
                "message": result.get("message", "AI调用失败")
            }
            
            # 添加回退信息到错误消息中
            if result.get('models_tried', 0) > 1:
                error_result["message"] += f"（已尝试 {result.get('models_tried')} 个模型）"
            
            return error_result
    except (ImportError, Exception) as e:
        # 如果新系统不可用或失败，使用旧实现
        logging.warning(f"使用AI适配器系统失败，回退到旧实现: {e}")
        
        try:
            client = openai.OpenAI(api_key=api_key, base_url=base_url, timeout=60.0)
            messages = [{'role': 'system', 'content': '你是一个专业的HR助手，总是返回一个纯净的、不带任何额外解释的JSON对象或数组。'},
                          {'role': 'user', 'content': prompt}]
            completion_params = {'model': model_name, 'messages': messages, 'temperature': 0.1, 'response_format': {"type": "json_object"}}
            completion = client.chat.completions.create(**completion_params)
            content = completion.choices[0].message.content
            data = json.loads(content)
            if isinstance(data, dict) and "jobs" in data and isinstance(data["jobs"], list):
                return data["jobs"]
            if isinstance(data, dict) and "candidates" in data and isinstance(data["candidates"], list):
                return data["candidates"]
            return data
        except openai.AuthenticationError:
            return {"error": "认证失败", "message": f"服务商 '{provider_for_db_lookup.upper()}' 的API密钥无效、过期或权限不足。请检查并更新密钥。"}
        except openai.RateLimitError:
            return {"error": "请求超限", "message": f"您对 '{provider_for_db_lookup.upper()}' 的请求频率过高或已超出当月额度。"}
        except openai.NotFoundError:
             return {"error": "模型未找到", "message": f"所选模型 '{model_name}' 不存在或当前服务商不支持。"}
        except openai.APITimeoutError:
            return {"error": "请求超时", "message": f"连接 '{provider_for_db_lookup.upper()}' 的API接口超时，请检查网络或稍后重试。"}
        except json.JSONDecodeError:
            return {"error": "格式错误", "message": f"AI模型返回了非JSON格式的内容，无法解析。"}
        except Exception as e:
            logging.error(f"调用 {provider_for_db_lookup} API时发生未知错误: {e}")
            return {"error": "未知错误", "message": f"调用API时发生未知错误: {e}"}

def parse_multiple_job_descriptions(text: str, provider_key: str, user: User):
    """解析可能包含多个职位的文本块"""
    keyword_list_str = '", "'.join(RESEARCH_DIRECTION_KEYWORDS)
    prompt = f"""
    你是一个专业的HR助手，负责将非结构化的职位描述(JD)文本精确地解析为结构化的JSON对象数组。
    文本块中可能包含一个或多个独立的职位描述。请你识别出所有的职位，并为每一个职位生成一个JSON对象。

    **【关键词提取字段要求】**：
    
    1. "keywords" 字段的输出格式必须是 **JSON 字符串数组**，如：
    ```json
    ["大模型", "自然语言处理", "推荐系统"]
    ```
    
    2. 所有关键词只能从下列"研究方向关键词列表"中选择：
    ["{keyword_list_str}"]
    
    3. 如果解析内容中未发现任何关键词，返回空数组 []，不要返回字符串、"无" 或 null。
    
    4. 严禁输出解释性语句、句子或段落，例如：
       - "该职位要求推荐系统" ❌
       - "关键词为：推荐系统、大模型" ❌  
       - "无关键词" ❌
       - "null" ❌
       - "推荐系统，大模型" ❌（这是字符串，不是数组）
    
    5. 模型必须严格控制输出，不能发散或补充额外的词汇。

    **最终输出格式**:
    你必须返回一个根键为 "jobs" 的JSON对象，其值是一个JSON数组 `[]`。数组中的每个元素都是一个符合以下结构的JSON对象:
    {{
        "company_name": string,
        "title": string,
        "department": string,
        "salary_range": string,
        "level_set": string[],
        "locations": string[],
        "keywords": string[] (只能从研究方向关键词列表中选择，格式必须是JSON数组),
        "job_description": string,
        "job_requirement": string,
        "notes": string
    }}

    **规则**:
    1. 仔细分析整个文本，识别出所有独立的职位描述。
    2. 如果文本中只有一个职位，你的输出也必须是一个包含单个对象的JSON数组。
    3. 如果某个字段找不到信息，请使用空字符串 "" 或空数组 []。
    4. keywords字段必须严格按照上述要求执行，只选择列表中存在的关键词。
    5. 返回结果必须是一个能被`json.loads()`直接解析的、纯净的JSON对象。

    **待解析的JD文本**:
    ---
    {text}
    """
    return _call_ai_model(prompt, provider_key, user)

def parse_candidate_resume(text: str, provider_key: str, user: User):
    """解析候选人简历"""
    keyword_list_str = '", "'.join(RESEARCH_DIRECTION_KEYWORDS)
    prompt = f"""
    你是一个专业的HR助手，负责将候选人简历文本精确地解析为结构化的JSON对象。
    
    **【关键词提取字段要求】**：
    
    1. "keywords" 字段的输出格式必须是 **JSON 字符串数组**，如：
    ```json
    ["大模型", "自然语言处理", "推荐系统"]
    ```
    
    2. 所有关键词只能从下列"研究方向关键词列表"中选择：
    ["{keyword_list_str}"]
    
    3. 如果解析内容中未发现任何关键词，返回空数组 []，不要返回字符串、"无" 或 null。
    
    4. 严禁输出解释性语句、句子或段落，例如：
       - "该候选人擅长推荐系统" ❌
       - "关键词为：推荐系统、大模型" ❌
       - "无关键词" ❌
       - "null" ❌
       - "推荐系统，大模型" ❌（这是字符串，不是数组）
    
    5. 模型必须严格控制输出，不能发散或补充额外的词汇。

    **最终输出格式**:
    你必须返回一个根键为 "candidates" 的JSON对象，其值是一个JSON数组 `[]`。
    {{
        "name": string,
        "emails": string[],
        "homepage": string,
        "github_profile": string,
        "linkedin_profile": string,
        "external_id": integer | (可选) 候选人在其他系统中的数字ID,
        "birthday": string | (可选) 出生年月日，格式为 "YYYY-MM-DD" 或 "YYYY-MM" 或 "YYYY",
        "gender": string | (可选) 性别，只能是 "男"、"女"、"其他"、"未知" 中的一个,
        "location": string | (可选) 所在地，如 "北京"、"上海"、"深圳" 等,
        "education_level": string | (可选) 最高学历，只能是 "高中"、"大专"、"本科"、"硕士"、"博士"、"其他"、"未知" 中的一个,
        "predicted_position": string | (可选) AI根据简历内容判断该候选人目前从事或适合的职位名称，如 "AI算法工程师"、"机器学习工程师"、"深度学习研究员" 等,
        "keywords": string[] (只能从研究方向关键词列表中选择，格式必须是JSON数组)
    }}
    
    **规则**:
    1. 如果某个字段找不到信息，请使用空字符串 ""、空数组 [] 或 null。
    2. birthday字段如果只能确定年份，使用 "YYYY" 格式；如果能确定年月，使用 "YYYY-MM" 格式；如果能确定具体日期，使用 "YYYY-MM-DD" 格式。
    3. gender字段必须严格匹配给定的选项。
    4. education_level字段必须严格匹配给定的选项。
    5. predicted_position字段应该基于候选人的技能、工作经历、项目经验等综合判断，给出最合适的职位名称。
    6. keywords字段必须严格按照上述要求执行，只选择列表中存在的关键词。
    7. 返回结果必须是一个能被`json.loads()`直接解析的、纯净的JSON对象。
    
    **待解析的简历文本**:
    ---
    {text}
    """
    return _call_ai_model(prompt, provider_key, user)

def get_texts_from_file(file):
    """从上传的文件中提取文本列表 (支持TXT, XLSX, DOCX)"""
    try:
        if file.name.endswith('.txt'):
            content = file.read().decode("utf-8")
            return [j.strip() for j in re.split(r'\n\s*\n|\n---\n', content) if j.strip()]
        elif file.name.endswith('.xlsx'):
            df = pd.read_excel(file, engine='openpyxl').fillna('')
            return [", ".join(f"{c}: {v}" for c, v in row.items() if str(v).strip()) for _, row in df.iterrows()]
        elif file.name.endswith('.docx'):
            doc = docx.Document(file)
            return ["\n".join([p.text for p in doc.paragraphs])]
        return []
    except Exception as e:
        logging.error(f"解析文件 {file.name} 时出错: {e}")
        return []