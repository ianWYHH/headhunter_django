"""
OpenAI Compatible Adapter Base Class

This module provides a base class for adapters that use OpenAI-compatible APIs.
Most modern AI providers support OpenAI-compatible endpoints.
"""

import openai
from typing import Dict, Any, List
from .base import AIAdapter, AIAdapterError


class OpenAICompatibleAdapter(AIAdapter):
    """
    Base adapter for providers that support OpenAI-compatible APIs.
    
    This includes providers like Qwen, Kimi, Doubao, DeepSeek, Together AI, etc.
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.timeout = config.get('timeout', 60.0)
        self.temperature = config.get('temperature', 0.1)
        self.max_tokens = config.get('max_tokens', None)
    
    def get_api_endpoint(self) -> str:
        """Get the API endpoint URL."""
        return self.base_url
    
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get standard OpenAI-compatible headers."""
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        """Format request for OpenAI-compatible API."""
        request_data = {
            'model': self.model_name,
            'messages': messages,
            'temperature': kwargs.get('temperature', self.temperature),
        }
        
        # Add max_tokens if specified
        max_tokens = kwargs.get('max_tokens', self.max_tokens)
        if max_tokens:
            request_data['max_tokens'] = max_tokens
        
        # Add response format for JSON mode if supported by the model
        if kwargs.get('json_mode', True) and self._supports_json_mode():
            request_data['response_format'] = {"type": "json_object"}
        
        return request_data
    
    def _supports_json_mode(self) -> bool:
        """Check if the model supports JSON mode based on configuration."""
        return self.config.get('supports_json_mode', True)
    
    def _make_api_call(self, api_key: str, request_data: Dict[str, Any]) -> Any:
        """Make API call using OpenAI client."""
        try:
            client = openai.OpenAI(
                api_key=api_key,
                base_url=self.base_url,
                timeout=self.timeout
            )
            
            response = client.chat.completions.create(**request_data)
            return response
            
        except openai.APIError as e:
            raise AIAdapterError(
                f"OpenAI API error: {e.message}",
                error_type="api_error",
                details={'status_code': e.status_code, 'type': e.type}
            )
        except openai.APITimeoutError as e:
            raise AIAdapterError(
                "API request timed out",
                error_type="timeout_error"
            )
        except openai.RateLimitError as e:
            raise AIAdapterError(
                "Rate limit exceeded",
                error_type="rate_limit_error"
            )
        except openai.AuthenticationError as e:
            raise AIAdapterError(
                "Authentication failed",
                error_type="auth_error"
            )
        except Exception as e:
            raise AIAdapterError(
                f"Unexpected error: {str(e)}",
                error_type="unknown_error"
            )
    
    def _extract_content(self, response: Any) -> str:
        """Extract content from OpenAI-compatible response."""
        if hasattr(response, 'choices') and response.choices:
            choice = response.choices[0]
            if hasattr(choice, 'message') and hasattr(choice.message, 'content'):
                return choice.message.content
        
        raise AIAdapterError(
            "Invalid response format from API",
            error_type="response_error"
        )