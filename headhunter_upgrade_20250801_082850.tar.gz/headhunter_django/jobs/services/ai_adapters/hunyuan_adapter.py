"""
Hunyuan (Tencent Cloud) Adapter

Adapter for Tencent's Hunyuan models.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class HunyuanAdapter(OpenAICompatibleAdapter):
    """Adapter for Tencent Hunyuan models."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on Hunyuan model variant."""
        model_limits = {
            'hunyuan-lite': 4096,
            'hunyuan-standard': 8192,
            'hunyuan-pro': 32768,
            'hunyuan-turbo': 16384,
        }
        return model_limits.get(self.model_name, 32768)
    
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get headers for Tencent Cloud API."""
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-TC-Action": "ChatCompletions"  # Tencent Cloud specific
        }
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for Tencent Hunyuan API."""
        request_data = super().format_request(messages, **kwargs)
        
        # Hunyuan specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 1.0),
            'stream': kwargs.get('stream', False),
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle Hunyuan-specific errors."""
        error_str = str(error).lower()
        
        if "signature" in error_str or "invalid_credential" in error_str:
            return self._create_error_response(
                "凭证无效",
                "腾讯云API凭证无效，请检查密钥配置。",
                "auth_error"
            )
        elif "qps_limit" in error_str:
            return self._create_error_response(
                "QPS限制",
                "请求频率超过腾讯云API限制，请降低请求频率。",
                "rate_limit_error"
            )
        elif "text_moderation" in error_str:
            return self._create_error_response(
                "内容审核",
                "输入内容未通过腾讯云内容审核，请修改后重试。",
                "content_error"
            )
        
        return super().handle_error(error)