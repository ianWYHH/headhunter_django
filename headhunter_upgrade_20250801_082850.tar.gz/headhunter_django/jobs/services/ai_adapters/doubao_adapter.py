"""
Doubao (ByteDance Volcano Engine) Adapter

Adapter for ByteDance's Doubao models via Volcano Engine.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class DoubaoAdapter(OpenAICompatibleAdapter):
    """Adapter for Doubao models by ByteDance."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on Doubao model variant."""
        model_limits = {
            'doubao-pro-4k': 4096,
            'doubao-pro-32k': 32768,
            'doubao-pro-128k': 131072,
            'doubao-lite-4k': 4096,
            'doubao-lite-32k': 32768,
        }
        return model_limits.get(self.model_name, 32768)
    
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get headers for Volcano Engine API."""
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-TT-LOGID": "doubao-request"  # ByteDance specific header
        }
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for Volcano Engine API."""
        request_data = super().format_request(messages, **kwargs)
        
        # Doubao specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 0.7),
            'top_k': kwargs.get('top_k', 0),  # Doubao supports top_k
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle Doubao-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_authentication" in error_str:
            return self._create_error_response(
                "认证失败",
                "火山引擎API认证失败，请检查API密钥。",
                "auth_error"
            )
        elif "model_overload" in error_str:
            return self._create_error_response(
                "模型繁忙",
                f"Doubao {self.model_name} 模型当前繁忙，请稍后重试。",
                "server_error"
            )
        elif "content_filter" in error_str:
            return self._create_error_response(
                "内容被过滤",
                "输入内容触发了安全过滤策略，请修改后重试。",
                "content_error"
            )
        
        return super().handle_error(error)