"""
ChatGLM (Zhipu AI) Adapter

Adapter for Zhipu AI's ChatGLM models.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class ChatGLMAdapter(OpenAICompatibleAdapter):
    """Adapter for ChatGLM models by Zhipu AI."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on ChatGLM model variant."""
        model_limits = {
            'glm-4': 128000,
            'glm-4v': 128000,
            'glm-3-turbo': 128000,
            'chatglm3-6b': 8192,
        }
        return model_limits.get(self.model_name, 128000)
    
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get headers for Zhipu AI API."""
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "headhunter-django/1.0"
        }
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for Zhipu AI API."""
        request_data = super().format_request(messages, **kwargs)
        
        # ChatGLM specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 0.7),
            'do_sample': kwargs.get('do_sample', True),
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle ChatGLM-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_api_key" in error_str:
            return self._create_error_response(
                "API密钥无效",
                "智谱AI API密钥无效，请检查密钥是否正确。",
                "auth_error"
            )
        elif "model_not_exist" in error_str:
            return self._create_error_response(
                "模型不存在",
                f"ChatGLM模型 {self.model_name} 不存在或无权限访问。",
                "model_error"
            )
        elif "context_too_long" in error_str:
            return self._create_error_response(
                "上下文过长",
                f"输入内容超过了 ChatGLM {self.model_name} 的上下文限制。",
                "context_error"
            )
        
        return super().handle_error(error)