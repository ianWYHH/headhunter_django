"""
Qwen (Alibaba DashScope) Adapter

Adapter for Alibaba's Qwen models via DashScope API.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class QwenAdapter(OpenAICompatibleAdapter):
    """Adapter for Qwen models via Alibaba DashScope."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on model variant."""
        model_limits = {
            'qwen-turbo': 8192,
            'qwen-plus': 32768, 
            'qwen-max': 8192,
            'qwen-max-longcontext': 28000,
        }
        return model_limits.get(self.model_name, 8192)
    
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get headers for DashScope API."""
        return {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-DashScope-SSE": "disable"  # Disable server-sent events
        }
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for DashScope API."""
        request_data = super().format_request(messages, **kwargs)
        
        # DashScope specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 0.8),
            'repetition_penalty': kwargs.get('repetition_penalty', 1.1),
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle Qwen-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_api_key" in error_str:
            return self._create_error_response(
                "API密钥无效",
                "DashScope API密钥无效，请检查密钥是否正确。",
                "auth_error"
            )
        elif "insufficient_quota" in error_str:
            return self._create_error_response(
                "配额不足",
                "DashScope账户配额不足，请充值后重试。",
                "quota_error"
            )
        elif "model_not_found" in error_str:
            return self._create_error_response(
                "模型不存在",
                f"Qwen模型 {self.model_name} 不存在或无权限访问。",
                "model_error"
            )
        
        return super().handle_error(error)