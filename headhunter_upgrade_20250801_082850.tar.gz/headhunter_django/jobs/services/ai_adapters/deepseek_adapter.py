"""
DeepSeek Adapter

Adapter for DeepSeek AI models.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class DeepSeekAdapter(OpenAICompatibleAdapter):
    """Adapter for DeepSeek AI models."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on DeepSeek model variant."""
        model_limits = {
            'deepseek-chat': 32768,
            'deepseek-coder': 16384,
            'deepseek-math': 4096,
        }
        return model_limits.get(self.model_name, 32768)
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for DeepSeek API."""
        request_data = super().format_request(messages, **kwargs)
        
        # DeepSeek specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 1.0),
            'frequency_penalty': kwargs.get('frequency_penalty', 0.0),
            'presence_penalty': kwargs.get('presence_penalty', 0.0),
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle DeepSeek-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_api_key" in error_str:
            return self._create_error_response(
                "API密钥无效",
                "DeepSeek API密钥无效，请检查密钥是否正确。",
                "auth_error"
            )
        elif "insufficient_balance" in error_str:
            return self._create_error_response(
                "余额不足",
                "DeepSeek账户余额不足，请充值后重试。",
                "quota_error"
            )
        elif "context_limit_exceeded" in error_str:
            return self._create_error_response(
                "上下文超限",
                f"输入文本超过了 DeepSeek {self.model_name} 的上下文限制。",
                "context_error"
            )
        
        return super().handle_error(error)