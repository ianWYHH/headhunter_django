"""
Together AI Adapter

Adapter for Together AI models.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class TogetherAdapter(OpenAICompatibleAdapter):
    """Adapter for Together AI models."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on Together AI model variant."""
        model_limits = {
            'mistralai/Mixtral-8x22B-Instruct-v0.1': 65536,
            'meta-llama/Llama-3.1-70B-Instruct': 131072,
            'meta-llama/Llama-3.1-8B-Instruct': 131072,
            'codellama/CodeLlama-34b-Instruct-hf': 16384,
        }
        return model_limits.get(self.model_name, 32768)
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for Together AI API."""
        request_data = super().format_request(messages, **kwargs)
        
        # Together AI specific parameters
        request_data.update({
            'top_p': kwargs.get('top_p', 1.0),
            'top_k': kwargs.get('top_k', 50),
            'repetition_penalty': kwargs.get('repetition_penalty', 1.0),
            'stop': kwargs.get('stop', []),
        })
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle Together AI-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_api_key" in error_str:
            return self._create_error_response(
                "API密钥无效",
                "Together AI API密钥无效，请检查密钥是否正确。",
                "auth_error"
            )
        elif "credit_limit" in error_str or "quota" in error_str:
            return self._create_error_response(
                "额度不足",
                "Together AI账户额度不足，请充值后重试。",
                "quota_error"
            )
        elif "model_not_found" in error_str:
            return self._create_error_response(
                "模型不存在",
                f"Together AI模型 {self.model_name} 不存在或无权限访问。",
                "model_error"
            )
        elif "server_overloaded" in error_str:
            return self._create_error_response(
                "服务器过载",
                "Together AI服务器当前过载，请稍后重试。",
                "server_error"
            )
        
        return super().handle_error(error)