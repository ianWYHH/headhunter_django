"""
MiniMax Adapter

Adapter for MiniMax AI models.
"""

from typing import Dict, Any
from .openai_compatible import OpenAICompatibleAdapter


class MiniMaxAdapter(OpenAICompatibleAdapter):
    """Adapter for MiniMax AI models."""
    
    def get_context_limit(self) -> int:
        """Get context limit based on MiniMax model variant."""
        model_limits = {
            'abab6.5-chat': 245760,  # ~240K tokens
            'abab6-chat': 200000,
            'abab5.5-chat': 16384,
        }
        return model_limits.get(self.model_name, 200000)
    
    def get_api_endpoint(self) -> str:
        """MiniMax uses a different endpoint structure."""
        # MiniMax API endpoint is already complete in base_url
        return self.base_url
    
    def format_request(self, messages, **kwargs) -> Dict[str, Any]:
        """Format request for MiniMax API."""
        # MiniMax uses a different request format
        request_data = {
            'model': self.model_name,
            'messages': messages,
            'temperature': kwargs.get('temperature', self.temperature),
            'top_p': kwargs.get('top_p', 0.95),
            'stream': kwargs.get('stream', False),
        }
        
        # MiniMax specific parameters
        request_data.update({
            'mask_sensitive_info': kwargs.get('mask_sensitive_info', True),
            'beam_width': kwargs.get('beam_width', 1),
        })
        
        # Add max_tokens if specified
        max_tokens = kwargs.get('max_tokens', self.max_tokens)
        if max_tokens:
            request_data['max_tokens'] = max_tokens
        
        return request_data
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """Handle MiniMax-specific errors."""
        error_str = str(error).lower()
        
        if "invalid_api_key" in error_str:
            return self._create_error_response(
                "API密钥无效",
                "MiniMax API密钥无效，请检查密钥是否正确。",
                "auth_error"
            )
        elif "balance_insufficient" in error_str:
            return self._create_error_response(
                "余额不足",
                "MiniMax账户余额不足，请充值后重试。",
                "quota_error"
            )
        elif "content_filtered" in error_str:
            return self._create_error_response(
                "内容被过滤",
                "输入内容触发了MiniMax内容安全策略。",
                "content_error"
            )
        elif "model_overloaded" in error_str:
            return self._create_error_response(
                "模型过载",
                f"MiniMax {self.model_name} 模型当前负载过高，请稍后重试。",
                "server_error"
            )
        
        return super().handle_error(error)