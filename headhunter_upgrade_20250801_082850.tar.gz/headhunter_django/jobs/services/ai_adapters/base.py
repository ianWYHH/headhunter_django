"""
Base AI Adapter Class

This module defines the base adapter interface for all AI model providers.
"""

import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from django.contrib.auth.models import User

logger = logging.getLogger(__name__)


class AIAdapterError(Exception):
    """Base exception for AI adapter errors."""
    def __init__(self, message: str, error_type: str = "unknown", details: Optional[Dict] = None):
        self.message = message
        self.error_type = error_type
        self.details = details or {}
        super().__init__(self.message)


class AIAdapter(ABC):
    """
    Base class for all AI model adapters.
    
    Each adapter should implement the specific logic for communicating with
    a particular AI model provider while maintaining a consistent interface.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize the adapter with configuration.
        
        Args:
            config: Configuration dictionary containing provider-specific settings
        """
        self.config = config
        self.provider = config.get('provider')
        self.base_url = config.get('base_url')
        self.model_name = config.get('model_name')
        self.name = config.get('name', self.provider)
        
        # Validate required config
        self._validate_config()
    
    def _validate_config(self):
        """Validate that required configuration is present."""
        required_fields = ['provider', 'base_url', 'model_name']
        missing_fields = [field for field in required_fields if not self.config.get(field)]
        
        if missing_fields:
            raise AIAdapterError(
                f"Missing required configuration fields: {missing_fields}",
                error_type="config_error",
                details={'missing_fields': missing_fields}
            )
    
    @abstractmethod
    def get_api_endpoint(self) -> str:
        """Get the API endpoint URL for this provider."""
        pass
    
    @abstractmethod
    def get_headers(self, api_key: str) -> Dict[str, str]:
        """Get the headers required for API requests."""
        pass
    
    @abstractmethod
    def get_context_limit(self) -> int:
        """Get the context/token limit for this model."""
        pass
    
    @abstractmethod
    def format_request(self, messages: List[Dict], **kwargs) -> Dict[str, Any]:
        """Format the request payload for this provider's API."""
        pass
    
    def send_request(self, prompt: str, user: User, **kwargs) -> Dict[str, Any]:
        """
        Send a request to the AI model.
        
        Args:
            prompt: The prompt to send to the model
            user: The user making the request
            **kwargs: Additional parameters
            
        Returns:
            Dict containing the response or error information
        """
        try:
            # Get API key
            api_key = self._get_api_key(user)
            if not api_key:
                return self._create_error_response(
                    "API密钥缺失", 
                    f"未找到 {self.provider.upper()} 的API密钥，请先在API密钥管理页面添加。",
                    "auth_error"
                )
            
            # Prepare messages
            messages = self._prepare_messages(prompt, **kwargs)
            
            # Format request
            request_data = self.format_request(messages, **kwargs)
            
            # Make API call
            response = self._make_api_call(api_key, request_data)
            
            # Handle response
            return self.handle_response(response)
            
        except Exception as e:
            logger.exception(f"Error in {self.provider} adapter: {e}")
            return self.handle_error(e)
    
    def handle_response(self, response: Any) -> Dict[str, Any]:
        """
        Handle the response from the AI model.
        
        Args:
            response: Raw response from the API
            
        Returns:
            Processed response dictionary
        """
        try:
            # Extract content from response
            content = self._extract_content(response)
            
            # Parse JSON if possible
            try:
                data = json.loads(content)
                return {"success": True, "data": data}
            except json.JSONDecodeError:
                # Return as plain text if not valid JSON
                return {"success": True, "data": {"content": content}}
                
        except Exception as e:
            logger.error(f"Error handling response from {self.provider}: {e}")
            return self.handle_error(e)
    
    def handle_error(self, error: Exception) -> Dict[str, Any]:
        """
        Handle errors that occur during API calls.
        
        Args:
            error: The exception that occurred
            
        Returns:
            Error response dictionary
        """
        if isinstance(error, AIAdapterError):
            return self._create_error_response(error.error_type, error.message, error.error_type)
        
        # Map common errors
        error_str = str(error).lower()
        
        if "timeout" in error_str:
            return self._create_error_response(
                "请求超时", 
                f"{self.provider} API响应超时，请稍后重试。",
                "timeout_error"
            )
        elif "unauthorized" in error_str or "401" in error_str:
            return self._create_error_response(
                "认证失败", 
                f"{self.provider} API密钥无效或已过期。",
                "auth_error"
            )
        elif "rate limit" in error_str or "429" in error_str:
            return self._create_error_response(
                "请求频率限制", 
                f"{self.provider} API请求过于频繁，请稍后重试。",
                "rate_limit_error"
            )
        elif "quota" in error_str or "insufficient" in error_str:
            return self._create_error_response(
                "配额不足", 
                f"{self.provider} API配额不足，请检查账户余额。",
                "quota_error"
            )
        else:
            return self._create_error_response(
                "API调用失败", 
                f"{self.provider} API调用出错: {str(error)}",
                "api_error"
            )
    
    def _get_api_key(self, user: User) -> Optional[str]:
        """Get the API key for this provider from the database."""
        try:
            from ..utils import decrypt_key
            from ...models import ApiKey
            
            api_key_obj = ApiKey.objects.get(user=user, provider=self.provider)
            return decrypt_key(api_key_obj.api_key_encrypted)
        except ApiKey.DoesNotExist:
            return None
        except Exception as e:
            logger.error(f"Error retrieving API key for {self.provider}: {e}")
            return None
    
    def _prepare_messages(self, prompt: str, **kwargs) -> List[Dict]:
        """Prepare the messages array for the API call."""
        system_message = kwargs.get('system_message', 
            '你是一个专业的HR助手，总是返回一个纯净的、不带任何额外解释的JSON对象或数组。')
        
        return [
            {'role': 'system', 'content': system_message},
            {'role': 'user', 'content': prompt}
        ]
    
    @abstractmethod
    def _make_api_call(self, api_key: str, request_data: Dict[str, Any]) -> Any:
        """Make the actual API call to the provider."""
        pass
    
    @abstractmethod
    def _extract_content(self, response: Any) -> str:
        """Extract the content from the API response."""
        pass
    
    def _create_error_response(self, error_type: str, message: str, code: str) -> Dict[str, Any]:
        """Create a standardized error response."""
        return {
            "success": False,
            "error": error_type,
            "message": message,
            "code": code,
            "provider": self.provider
        }
    
    def __str__(self) -> str:
        return f"{self.name} ({self.provider})"
    
    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}(provider='{self.provider}', model='{self.model_name}')>"