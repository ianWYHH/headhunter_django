"""
AI Adapter Factory

Factory class for creating appropriate AI adapters based on provider configuration.
"""

from typing import Dict, Any, Optional
from django.conf import settings

from .base import AIAdapter, AIAdapterError
from .qwen_adapter import QwenAdapter
from .kimi_adapter import KimiAdapter
from .doubao_adapter import DoubaoAdapter
from .hunyuan_adapter import HunyuanAdapter
from .chatglm_adapter import ChatGLMAdapter
from .minimax_adapter import MiniMaxAdapter
from .deepseek_adapter import DeepSeekAdapter
from .together_adapter import TogetherAdapter


class AIAdapterFactory:
    """Factory for creating AI adapters based on provider type."""
    
    # Mapping of provider names to their adapter classes
    ADAPTER_MAPPING = {
        'qwen': QwenAdapter,
        'kimi': KimiAdapter,
        'doubao': DoubaoAdapter,
        'hunyuan': HunyuanAdapter,
        'chatglm': ChatGLMAdapter,
        'zhipu': ChatGLMAdapter,  # Alias for ChatGLM
        'minimax': MiniMaxAdapter,
        'deepseek': DeepSeekAdapter,
        'together': TogetherAdapter,
    }
    
    @classmethod
    def create_adapter(cls, provider_key: str) -> AIAdapter:
        """
        Create an adapter instance for the specified provider.
        
        Args:
            provider_key: The key from model registry (e.g., 'qwen_plus', 'kimi_32k')
            
        Returns:
            An instance of the appropriate AIAdapter subclass
            
        Raises:
            AIAdapterError: If the provider is not supported or configuration is invalid
        """
        # Try to get configuration from new model registry first
        try:
            from ..ai_config import model_registry
            model_registry.ensure_loaded()
            model_config_obj = model_registry.get_model(provider_key)
            
            if model_config_obj:
                # Convert ModelConfig to dict for adapter
                model_config = model_config_obj.to_dict()
                provider = model_config['provider']
            else:
                # Fallback to legacy settings
                model_config = settings.AI_MODELS.get(provider_key)
                if not model_config:
                    raise AIAdapterError(
                        f"Model configuration for '{provider_key}' not found",
                        error_type="config_error",
                        details={'provider_key': provider_key}
                    )
                provider = model_config.get('provider')
        except ImportError:
            # Fallback to legacy settings if new system not available
            model_config = settings.AI_MODELS.get(provider_key)
            if not model_config:
                raise AIAdapterError(
                    f"Model configuration for '{provider_key}' not found in settings",
                    error_type="config_error",
                    details={'provider_key': provider_key}
                )
            provider = model_config.get('provider')
        
        if not provider:
            raise AIAdapterError(
                f"Provider not specified in configuration for '{provider_key}'",
                error_type="config_error",
                details={'provider_key': provider_key, 'config': model_config}
            )
        
        # Get the adapter class
        adapter_class = cls.ADAPTER_MAPPING.get(provider)
        if not adapter_class:
            raise AIAdapterError(
                f"No adapter available for provider '{provider}'",
                error_type="unsupported_provider",
                details={
                    'provider': provider,
                    'provider_key': provider_key,
                    'supported_providers': list(cls.ADAPTER_MAPPING.keys())
                }
            )
        
        # Create and return the adapter instance
        try:
            return adapter_class(model_config)
        except Exception as e:
            raise AIAdapterError(
                f"Failed to create adapter for provider '{provider}': {str(e)}",
                error_type="adapter_creation_error",
                details={'provider': provider, 'provider_key': provider_key, 'error': str(e)}
            )
    
    @classmethod
    def get_supported_providers(cls) -> Dict[str, str]:
        """
        Get a mapping of supported provider names to their descriptions.
        
        Returns:
            Dictionary mapping provider names to descriptions
        """
        return {
            'qwen': 'Alibaba Qwen (DashScope)',
            'kimi': 'Moonshot AI Kimi',
            'doubao': 'ByteDance Doubao (Volcano Engine)',
            'hunyuan': 'Tencent Hunyuan',
            'chatglm': 'Zhipu AI ChatGLM',
            'minimax': 'MiniMax AI',
            'deepseek': 'DeepSeek AI',
            'together': 'Together AI',
        }
    
    @classmethod
    def is_provider_supported(cls, provider: str) -> bool:
        """
        Check if a provider is supported.
        
        Args:
            provider: The provider name
            
        Returns:
            True if the provider is supported, False otherwise
        """
        return provider in cls.ADAPTER_MAPPING
    
    @classmethod
    def get_available_models(cls) -> Dict[str, Dict[str, Any]]:
        """
        Get all available models with their configurations.
        
        Returns:
            Dictionary of model configurations
        """
        try:
            from ..ai_config import model_registry
            model_registry.ensure_loaded()
            models = model_registry.get_all_models()
            return {
                model_id: config.to_dict() 
                for model_id, config in models.items()
            }
        except ImportError:
            # Fallback to legacy settings
            return getattr(settings, 'AI_MODELS', {})
    
    @classmethod
    def get_models_by_provider(cls, provider: str) -> Dict[str, Dict[str, Any]]:
        """
        Get all models for a specific provider.
        
        Args:
            provider: The provider name
            
        Returns:
            Dictionary of model configurations for the specified provider
        """
        all_models = cls.get_available_models()
        return {
            key: config for key, config in all_models.items()
            if config.get('provider') == provider
        }