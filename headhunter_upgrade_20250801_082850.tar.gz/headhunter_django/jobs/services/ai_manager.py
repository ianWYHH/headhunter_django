"""
AI Manager

Central manager for AI model interactions using the adapter pattern.
This replaces the direct AI model calling logic with a clean, extensible architecture.
"""

import logging
from typing import Dict, Any, Optional, List
from django.contrib.auth.models import User
from django.conf import settings

from .ai_adapters import AIAdapterFactory, AIAdapter, AIAdapterError
from .ai_config import config_manager
from .ai_fallback import FallbackManager, RetryStrategy

logger = logging.getLogger(__name__)


class AIManager:
    """
    Central manager for AI model interactions.
    
    This class provides a high-level interface for interacting with various AI models
    through their respective adapters, maintaining backward compatibility while
    offering improved error handling and extensibility.
    """
    
    def __init__(self):
        """Initialize the AI manager."""
        self._adapters_cache = {}
        self.fallback_manager = FallbackManager()
        self.retry_strategy = RetryStrategy()
    
    def get_adapter(self, provider_key: str) -> AIAdapter:
        """
        Get an adapter instance for the specified provider.
        
        Args:
            provider_key: The key from settings.AI_MODELS (e.g., 'qwen_plus', 'kimi_32k')
            
        Returns:
            An adapter instance
            
        Raises:
            AIAdapterError: If the adapter cannot be created
        """
        # Use cached adapter if available
        if provider_key in self._adapters_cache:
            return self._adapters_cache[provider_key]
        
        # Create new adapter
        adapter = AIAdapterFactory.create_adapter(provider_key)
        self._adapters_cache[provider_key] = adapter
        
        return adapter
    
    def call_model(self, prompt: str, provider_key: str, user: User, **kwargs) -> Dict[str, Any]:
        """
        Call an AI model with the specified prompt.
        
        This is the main entry point for AI model interactions, replacing the old
        _call_ai_model function with improved error handling and adapter-based architecture.
        
        Args:
            prompt: The prompt to send to the model
            provider_key: The model identifier from settings.AI_MODELS
            user: The user making the request
            **kwargs: Additional parameters to pass to the adapter
            
        Returns:
            Dictionary containing the response or error information
        """
        try:
            # Get the appropriate adapter
            adapter = self.get_adapter(provider_key)
            
            # Log the request
            logger.info(f"AI request to {adapter.provider} ({provider_key}) by user {user.username}")
            
            # Make the request
            result = adapter.send_request(prompt, user, **kwargs)
            
            # Log the result
            if result.get('success'):
                logger.info(f"AI request successful for {adapter.provider}")
            else:
                logger.warning(f"AI request failed for {adapter.provider}: {result.get('message', 'Unknown error')}")
            
            return result
            
        except AIAdapterError as e:
            logger.error(f"AI adapter error for provider {provider_key}: {e.message}")
            return {
                "success": False,
                "error": e.error_type,
                "message": e.message,
                "code": e.error_type,
                "provider": provider_key
            }
        except Exception as e:
            logger.exception(f"Unexpected error in AI manager for provider {provider_key}: {e}")
            return {
                "success": False,
                "error": "系统错误",
                "message": f"AI调用过程中发生未知错误: {str(e)}",
                "code": "system_error",
                "provider": provider_key
            }
    
    def call_model_with_fallback(self, prompt: str, user: User, primary_model: Optional[str] = None, 
                                fallback_models: Optional[List[str]] = None, **kwargs) -> Dict[str, Any]:
        """
        Call an AI model with automatic fallback support.
        
        This method automatically retries failed requests and falls back to alternative models
        when the primary model fails, providing robust error handling and user-friendly messages.
        
        Args:
            prompt: The prompt to send to the model
            user: The user making the request
            primary_model: Primary model to use (if None, uses user's preferred model)
            fallback_models: List of fallback models (if None, uses user's fallback chain)
            **kwargs: Additional parameters to pass to the adapter
            
        Returns:
            Dictionary containing the response, fallback information, and error details
        """
        try:
            # Determine model chain
            if primary_model is None:
                selected_model = config_manager.select_model_for_user(user)
                if selected_model:
                    primary_model = selected_model.model_id
                else:
                    return {
                        "success": False,
                        "error": "no_models_available",
                        "message": "用户没有可用的AI模型，请配置API密钥",
                        "human_readable_log": ["❌ 没有可用的AI模型，请在API密钥管理页面配置密钥"]
                    }
            
            if fallback_models is None:
                fallback_models = config_manager.get_fallback_chain(user, primary_model)[1:]  # Exclude primary
            
            # Create request function
            def request_func(model_id: str) -> Dict[str, Any]:
                return self.call_model(prompt, model_id, user, **kwargs)
            
            # Execute with fallback
            context = {
                'prompt_length': len(prompt),
                'user_id': user.id,
                'request_params': kwargs
            }
            
            fallback_result = self.fallback_manager.execute_with_fallback(
                user=user,
                primary_model=primary_model,
                fallback_models=fallback_models,
                request_func=request_func,
                context=context
            )
            
            # Convert fallback result to standard response format
            response = {
                "success": fallback_result.success,
                "fallback_used": fallback_result.fallback_count > 0,
                "models_tried": fallback_result.models_tried,
                "total_retries": fallback_result.total_retries,
                "execution_time": fallback_result.total_time,
                "human_readable_log": fallback_result.human_readable_log
            }
            
            if fallback_result.success:
                response.update({
                    "data": fallback_result.data,
                    "final_model": fallback_result.final_model,
                    "summary": self.fallback_manager.get_fallback_summary(fallback_result)
                })
                
                # Log success with details
                logger.info(f"AI request successful for user {user.username}: {response['summary']}")
            else:
                response.update({
                    "error": fallback_result.error or "all_models_failed",
                    "message": fallback_result.error or "所有模型均失败",
                    "attempts": [
                        {
                            "model_id": attempt.model_id,
                            "error": attempt.error_message,
                            "retries": attempt.retry_count
                        }
                        for attempt in fallback_result.attempts
                    ]
                })
                
                # Log failure with details
                logger.error(f"AI request failed for user {user.username} after {fallback_result.models_tried} models")
            
            return response
            
        except Exception as e:
            logger.exception(f"Unexpected error in fallback AI manager: {e}")
            return {
                "success": False,
                "error": "system_error",
                "message": f"回退系统发生未知错误: {str(e)}",
                "human_readable_log": [f"❌ 系统错误: {str(e)}"]
            }
    
    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Get all available AI models.
        
        Returns:
            Dictionary of available models with their configurations
        """
        try:
            # Use new configuration system
            return AIAdapterFactory.get_available_models()
        except Exception as e:
            logger.error(f"Error getting available models: {e}")
            return getattr(settings, 'AI_MODELS', {})
    
    def get_models_by_provider(self, provider: str) -> Dict[str, Dict[str, Any]]:
        """
        Get all models for a specific provider.
        
        Args:
            provider: The provider name (e.g., 'qwen', 'kimi')
            
        Returns:
            Dictionary of models for the specified provider
        """
        return AIAdapterFactory.get_models_by_provider(provider)
    
    def get_supported_providers(self) -> Dict[str, str]:
        """
        Get all supported providers.
        
        Returns:
            Dictionary mapping provider names to descriptions
        """
        return AIAdapterFactory.get_supported_providers()
    
    def validate_provider_key(self, provider_key: str) -> bool:
        """
        Validate that a provider key is available.
        
        Args:
            provider_key: The provider key to validate
            
        Returns:
            True if the provider key is valid, False otherwise
        """
        return provider_key in self.get_available_models()
    
    def get_model_info(self, provider_key: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a specific model.
        
        Args:
            provider_key: The model key
            
        Returns:
            Model configuration dictionary or None if not found
        """
        return self.get_available_models().get(provider_key)
    
    def check_user_access(self, user: User, provider_key: str) -> Dict[str, Any]:
        """
        Check if a user has access to a specific AI model.
        
        Args:
            user: The user to check
            provider_key: The model key
            
        Returns:
            Dictionary with access status and details
        """
        try:
            # Use enhanced configuration manager
            return config_manager.validate_user_model_access(user, provider_key)
        except Exception as e:
            logger.error(f"Error checking user access for {provider_key}: {e}")
            return {
                "has_access": False,
                "reason": "system_error",
                "message": "检查访问权限时发生错误"
            }
    
    def get_user_available_models(self, user: User) -> Dict[str, Dict[str, Any]]:
        """
        Get all models that a user has access to (i.e., has API keys for).
        
        Args:
            user: The user
            
        Returns:
            Dictionary of available models for the user
        """
        try:
            # Use enhanced configuration manager
            models = config_manager.get_available_models_for_user(user)
            return {
                model_id: config.to_dict()
                for model_id, config in models.items()
            }
        except Exception as e:
            logger.error(f"Error getting user available models: {e}")
            return {}
    
    def clear_cache(self):
        """Clear the adapter cache."""
        self._adapters_cache.clear()
        logger.info("AI adapter cache cleared")
    
    def get_fallback_status(self, user: User) -> Dict[str, Any]:
        """
        Get the current fallback configuration for a user.
        
        Args:
            user: The user to check
            
        Returns:
            Dictionary with fallback configuration details
        """
        try:
            preferences = config_manager.get_user_preferences(user)
            available_models = config_manager.get_available_models_for_user(user)
            
            # Get the complete fallback chain
            primary_model = preferences.preferred_model
            if not primary_model:
                if available_models:
                    primary_model = next(iter(available_models.keys()))
                else:
                    return {
                        "has_fallback": False,
                        "error": "no_models_available",
                        "message": "用户没有可用的AI模型"
                    }
            
            fallback_chain = config_manager.get_fallback_chain(user, primary_model)
            
            # Validate each model in the chain
            validated_chain = []
            for model_id in fallback_chain:
                access = self.check_user_access(user, model_id)
                model_info = self.get_model_info(model_id)
                
                validated_chain.append({
                    "model_id": model_id,
                    "name": model_info.get('name', model_id),
                    "provider": model_info.get('provider', 'unknown'),
                    "has_access": access.get('has_access', False),
                    "access_reason": access.get('reason') if not access.get('has_access') else None
                })
            
            # Calculate fallback health
            accessible_models = [m for m in validated_chain if m['has_access']]
            fallback_health = "healthy" if len(accessible_models) >= 2 else "limited" if len(accessible_models) == 1 else "none"
            
            return {
                "has_fallback": len(accessible_models) > 1,
                "primary_model": primary_model,
                "fallback_chain": validated_chain,
                "accessible_models": len(accessible_models),
                "total_models": len(validated_chain),
                "fallback_health": fallback_health,
                "max_retries": preferences.max_retries,
                "recommendations": self._get_fallback_recommendations(accessible_models, fallback_health)
            }
            
        except Exception as e:
            logger.error(f"Error getting fallback status for user {user.username}: {e}")
            return {
                "has_fallback": False,
                "error": "system_error",
                "message": f"检查回退配置时发生错误: {str(e)}"
            }
    
    def _get_fallback_recommendations(self, accessible_models: List[Dict], health: str) -> List[str]:
        """Get recommendations for improving fallback configuration."""
        recommendations = []
        
        if health == "none":
            recommendations.append("请至少配置一个AI模型的API密钥")
        elif health == "limited":
            recommendations.append("建议配置多个AI服务商的API密钥以提高稳定性")
        elif len(accessible_models) < 3:
            recommendations.append("建议配置3个或更多AI模型以获得最佳回退保护")
        
        # Check provider diversity
        providers = set(m['provider'] for m in accessible_models)
        if len(providers) < 2 and len(accessible_models) > 1:
            recommendations.append("建议配置不同服务商的API密钥以避免单点故障")
        
        return recommendations


# Global instance for use throughout the application
ai_manager = AIManager()