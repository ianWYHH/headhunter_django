from django.contrib.auth.models import User
from ..models import Job, Candidate

# 研究方向关键词列表 - 用于高层匹配
RESEARCH_DIRECTION_KEYWORDS = {
    "大模型", "LLM", "ChatGPT", "Transformer", "预训练", "对齐", "指令微调", "SFT", "RLHF",
    "后训练", "Post-training", "Instruct-tuning", "Alignment",
    "多模态", "Multimodal", "图文", "语音多模态", "音视频理解",
    "强化学习", "Reinforcement Learning", "Actor-Critic", "PPO", "DQN",
    "自然语言处理", "NLP", "问答系统", "文本生成", "语言建模",
    "语音合成", "Speech Synthesis", "语音识别", "ASR", "TTS",
    "图神经网络", "GNN", "图表示学习", "Graph Learning",
    "推荐系统", "Recommendation", "大规模推荐",
    "知识图谱", "Knowledge Graph", "KG",
    "代码生成", "Code Generation", "Program Synthesis",
    "大模型安全", "模型压缩", "LoRA", "PEFT", "Prompt Engineering",
    "数据合成", "数据增强", "Synthetic Data",
    "因果推理", "Causal Inference", "AIGC", "Agent"
}


def find_matching_jobs(candidate: Candidate):
    """
    为指定候选人查找匹配的职位 (基于研究方向匹配)。
    匹配规则: 候选人和职位的研究方向关键词有任意一个重合即可。
    只考虑高层研究方向，忽略具体的技术技能和工具。
    
    :param candidate: Candidate 实例
    :return: 一个包含匹配职位信息的字典列表
    """
    if not candidate.keywords:
        return []

    matching_jobs = []
    
    # 提取候选人的研究方向关键词
    candidate_research_keywords = set()
    for keyword in candidate.keywords:
        if keyword in RESEARCH_DIRECTION_KEYWORDS:
            candidate_research_keywords.add(keyword)
    
    # 如果候选人没有研究方向关键词，返回空列表
    if not candidate_research_keywords:
        return []

    # 从所有活跃职位中进行匹配 (数据共享)
    active_jobs = Job.objects.filter(
        status__in=[Job.JobStatus.IN_PROGRESS, Job.JobStatus.PENDING]
    ).select_related('company')

    for job in active_jobs:
        if not job.keywords:
            continue

        # 提取职位的研究方向关键词
        job_research_keywords = set()
        for keyword in job.keywords:
            if keyword in RESEARCH_DIRECTION_KEYWORDS:
                job_research_keywords.add(keyword)
        
        # 如果职位没有研究方向关键词，跳过
        if not job_research_keywords:
            continue

        # 计算研究方向关键词的交集
        matched_research_keywords = candidate_research_keywords.intersection(job_research_keywords)

        if matched_research_keywords:
            matching_jobs.append({
                'job_id': job.id,
                'title': job.title,
                'company_name': job.company.name,
                'locations': job.locations,
                'level_set': job.level_set,
                'matched_keywords': list(matched_research_keywords),
                'match_count': len(matched_research_keywords),
                'candidate_research_areas': list(candidate_research_keywords),
                'job_research_areas': list(job_research_keywords)
            })

    # 按匹配关键词数量降序排序
    matching_jobs.sort(key=lambda x: x['match_count'], reverse=True)
    
    return matching_jobs


def get_research_direction_keywords():
    """
    获取所有研究方向关键词列表。
    
    :return: 研究方向关键词集合
    """
    return RESEARCH_DIRECTION_KEYWORDS.copy()


def filter_research_keywords(keywords_list):
    """
    从关键词列表中筛选出研究方向关键词。
    
    :param keywords_list: 关键词列表
    :return: 研究方向关键词列表
    """
    if not keywords_list:
        return []
    
    research_keywords = []
    for keyword in keywords_list:
        if keyword in RESEARCH_DIRECTION_KEYWORDS:
            research_keywords.append(keyword)
    
    return research_keywords


def calculate_research_match_score(candidate_keywords, job_keywords):
    """
    计算候选人和职位在研究方向上的匹配分数。
    
    :param candidate_keywords: 候选人关键词列表
    :param job_keywords: 职位关键词列表
    :return: 匹配分数字典，包含匹配数量、候选人研究方向数、职位研究方向数
    """
    candidate_research = set(filter_research_keywords(candidate_keywords))
    job_research = set(filter_research_keywords(job_keywords))
    
    if not candidate_research or not job_research:
        return {
            'match_count': 0,
            'match_ratio': 0.0,
            'candidate_research_count': len(candidate_research),
            'job_research_count': len(job_research),
            'matched_keywords': []
        }
    
    matched_keywords = candidate_research.intersection(job_research)
    match_count = len(matched_keywords)
    
    # 计算匹配比例 (匹配数量 / 候选人研究方向数量)
    match_ratio = match_count / len(candidate_research) if candidate_research else 0.0
    
    return {
        'match_count': match_count,
        'match_ratio': match_ratio,
        'candidate_research_count': len(candidate_research),
        'job_research_count': len(job_research),
        'matched_keywords': list(matched_keywords)
    }
